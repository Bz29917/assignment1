export interface DailyEarnings {
  date: string;
  total_orders: number;
  total_earnings: number;
  average_order_value: number;
}

export interface MonthlyEarnings {
  year: number;
  month: number;
  total_orders: number;
  total_earnings: number;
  average_order_value: number;
}

export interface DateRangeEarnings {
  date_range: {
    start_date: string;
    end_date: string;
  };
  summary: {
    total_orders: number;
    total_earnings: number;
    average_order_value: number;
  };
  daily_breakdown: {
    date: string;
    orders_count: number;
    earnings: number;
  }[];
}

export interface TopSellingProduct {
  id: number;
  name: string;
  price: number;
  discounted_price: number;
  category_name: string;
  brand_name: string;
  total_sold: number;
  total_revenue: number;
  times_ordered: number;
}

export interface ProductPerformance {
  product_performance: {
    id: number;
    name: string;
    price: number;
    discounted_price: number;
    initial_quantity: number;
    sold_quantity: number;
    current_quantity: number;
    times_ordered: number;
    total_units_sold: number;
    total_revenue: number;
    average_selling_price: number;
  };
  monthly_sales: {
    year: number;
    month: number;
    units_sold: number;
    revenue: number;
  }[];
}

export interface SalesByCategory {
  id: number;
  category_name: string;
  orders_count: number;
  units_sold: number;
  total_revenue: number;
}

export interface SalesByBrand {
  id: number;
  brand_name: string;
  orders_count: number;
  units_sold: number;
  total_revenue: number;
}

export interface Dashboard {
  overall: {
    total_orders: number;
    total_revenue: number;
    average_order_value: number;
    pending_orders: number;
    confirmed_orders: number;
  };
  today: {
    orders_today: number;
    revenue_today: number;
  };
  this_month: {
    orders_this_month: number;
    revenue_this_month: number;
  };
  products: {
    total_products: number;
    total_stock: number;
    available_stock: number;
    out_of_stock_count: number;
  };
  clients: {
    total_clients: number;
  };
}
