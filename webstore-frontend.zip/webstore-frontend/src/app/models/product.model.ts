export interface Product {
  id: number;
  name: string;
  description?: string;
  price: number;
  discount_percentage: number;
  discounted_price: number;
  initial_quantity: number;
  gender_id?: number;
  gender_name?: string;
  category_id?: number;
  category_name?: string;
  brand_id?: number;
  brand_name?: string;
  size_id?: number;
  size_name?: string;
  color_id?: number;
  color_name?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  sold_quantity?: number;
  current_quantity?: number;
}

export interface ProductQuantity {
  product_id: number;
  name: string;
  initial_quantity: number;
  sold_quantity: number;
  current_quantity: number;
}

export interface ProductSearchParams {
  gender?: string;
  category?: string;
  brand?: string;
  price_min?: number;
  price_max?: number;
  size?: string;
  color?: string;
  availability?: 'in_stock' | 'out_of_stock';
  page?: number;
  limit?: number;
}
