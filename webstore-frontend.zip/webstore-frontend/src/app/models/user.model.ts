export interface User {
  id: number;
  username: string;
  email: string;
  role: 'admin' | 'advanced_user' | 'simple_user';
  first_name?: string;
  last_name?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  last_login?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  role?: 'admin' | 'advanced_user' | 'simple_user';
  first_name?: string;
  last_name?: string;
}

export interface LoginResponse {
  message: string;
  token: string;
  user: User;
}

export interface ChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}
