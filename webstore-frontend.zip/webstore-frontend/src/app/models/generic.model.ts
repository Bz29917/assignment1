export interface Category {
  id: number;
  name: string;
  description?: string;
  created_at: string;
  updated_at?: string;
}

export interface Brand {
  id: number;
  name: string;
  description?: string;
  created_at: string;
  updated_at?: string;
}

export interface Size {
  id: number;
  name: string;
  sort_order?: number;
  created_at: string;
}

export interface Color {
  id: number;
  name: string;
  hex_code?: string;
  created_at: string;
}

export interface Gender {
  id: number;
  name: string;
  created_at: string;
}
