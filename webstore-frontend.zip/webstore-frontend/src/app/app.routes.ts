import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadComponent: () => import('./components/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'register',
    loadComponent: () =>
      import('./components/register/register.component').then((m) => m.RegisterComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./components/dashboard/dashboard.component').then((m) => m.DashboardComponent),
      },
      {
        path: 'products',
        loadComponent: () =>
          import('./components/products/product-list/product-list.component').then(
            (m) => m.ProductListComponent
          ),
      },
      {
        path: 'products/create',
        loadComponent: () =>
          import('./components/products/product-form/product-form.component').then(
            (m) => m.ProductFormComponent
          ),
      },
      {
        path: 'products/edit/:id',
        loadComponent: () =>
          import('./components/products/product-form/product-form.component').then(
            (m) => m.ProductFormComponent
          ),
      },
      {
        path: 'products/:id',
        loadComponent: () =>
          import('./components/products/product-detail/product-detail.component').then(
            (m) => m.ProductDetailComponent
          ),
      },
      {
        path: 'orders',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/orders/order-list/order-list.component').then(
            (m) => m.OrderListComponent
          ),
      },
      {
        path: 'orders/create',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/orders/order-form/order-form.component').then(
            (m) => m.OrderFormComponent
          ),
      },
      {
        path: 'orders/:id',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/orders/order-detail/order-detail.component').then(
            (m) => m.OrderDetailComponent
          ),
      },
      {
        path: 'clients',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/clients/client-list/client-list.component').then(
            (m) => m.ClientListComponent
          ),
      },
      {
        path: 'clients/create',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/clients/client-form/client-form.component').then(
            (m) => m.ClientFormComponent
          ),
      },
      {
        path: 'clients/edit/:id',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/clients/client-form/client-form.component').then(
            (m) => m.ClientFormComponent
          ),
      },
      {
        path: 'users',
        canActivate: [roleGuard],
        data: { roles: ['admin'] },
        loadComponent: () =>
          import('./components/users/user-list/user-list.component').then(
            (m) => m.UserListComponent
          ),
      },
      {
        path: 'users/edit/:id',
        canActivate: [roleGuard],
        data: { roles: ['admin'] },
        loadComponent: () =>
          import('./components/users/user-form/user-form.component').then(
            (m) => m.UserFormComponent
          ),
      },
      {
        path: 'reports',
        canActivate: [roleGuard],
        data: { roles: ['admin', 'advanced_user'] },
        loadComponent: () =>
          import('./components/reports/reports.component').then((m) => m.ReportsComponent),
      },
      {
        path: 'settings',
        loadComponent: () =>
          import('./components/settings/settings.component').then((m) => m.SettingsComponent),
      },
    ],
  },
  {
    path: '**',
    redirectTo: '/dashboard',
  },
];
