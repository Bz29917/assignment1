import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar">
      <div class="navbar-container">
        <div class="navbar-brand">
          <a routerLink="/dashboard">Web Store</a>
        </div>

        <div class="navbar-menu">
          <a routerLink="/dashboard" routerLinkActive="active">Dashboard</a>
          <a routerLink="/products" routerLinkActive="active">Products</a>
          <a
            routerLink="/orders"
            routerLinkActive="active"
            *ngIf="hasRole('admin', 'advanced_user')"
            >Orders</a
          >
          <a
            routerLink="/clients"
            routerLinkActive="active"
            *ngIf="hasRole('admin', 'advanced_user')"
            >Clients</a
          >
          <a routerLink="/users" routerLinkActive="active" *ngIf="hasRole('admin')">Users</a>
          <a
            routerLink="/reports"
            routerLinkActive="active"
            *ngIf="hasRole('admin', 'advanced_user')"
            >Reports</a
          >
        </div>

        <div class="navbar-user">
          <div class="user-info" *ngIf="currentUser">
            <span class="user-name">{{ currentUser.username }}</span>
            <span class="user-role">{{ currentUser.role | uppercase }}</span>
          </div>
          <button class="btn-logout" (click)="logout()">Logout</button>
        </div>
      </div>
    </nav>
  `,
  styles: [
    `
      .navbar {
        background: white;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        position: sticky;
        top: 0;
        z-index: 100;
      }

      .navbar-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 64px;
      }

      .navbar-brand a {
        font-size: 20px;
        font-weight: 700;
        color: #667eea;
        text-decoration: none;
      }

      .navbar-menu {
        display: flex;
        gap: 30px;
        flex: 1;
        justify-content: center;
      }

      .navbar-menu a {
        color: #666;
        text-decoration: none;
        font-weight: 500;
        transition: color 0.3s ease;
        padding: 8px 12px;
        border-radius: 6px;
      }

      .navbar-menu a:hover {
        color: #667eea;
        background: #f5f6ff;
      }

      .navbar-menu a.active {
        color: #667eea;
        background: #f5f6ff;
      }

      .navbar-user {
        display: flex;
        align-items: center;
        gap: 15px;
      }

      .user-info {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
      }

      .user-name {
        font-weight: 600;
        color: #333;
        font-size: 14px;
      }

      .user-role {
        font-size: 11px;
        color: #999;
        font-weight: 500;
      }

      .btn-logout {
        padding: 8px 20px;
        background: #667eea;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.3s ease;
      }

      .btn-logout:hover {
        background: #5568d3;
      }
    `,
  ],
})
export class NavbarComponent implements OnInit {
  currentUser: User | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user;
    });
  }

  hasRole(...roles: string[]): boolean {
    return this.authService.hasRole(...roles);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
