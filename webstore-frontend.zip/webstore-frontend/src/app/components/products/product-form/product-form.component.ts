import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../navbar/navbar.component';
import { ProductService } from '../../../services/product.service';
import { GenericService } from '../../../services/generic.service';
import { Category, Brand, Gender, Size, Color } from '../../../models/generic.model';

@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>{{ isEditMode ? 'Edit Product' : 'Create Product' }}</h1>
      </div>

      <div class="form-card">
        <form [formGroup]="productForm" (ngSubmit)="onSubmit()">
          <div class="form-row">
            <div class="form-group">
              <label for="name">Product Name *</label>
              <input
                type="text"
                id="name"
                formControlName="name"
                class="form-control"
                [class.error]="productForm.get('name')?.invalid && productForm.get('name')?.touched"
                placeholder="Nike Air Max"
              />
              <div
                class="error-message"
                *ngIf="productForm.get('name')?.invalid && productForm.get('name')?.touched"
              >
                Product name is required
              </div>
            </div>

            <div class="form-group">
              <label for="price">Price *</label>
              <input
                type="number"
                id="price"
                formControlName="price"
                class="form-control"
                [class.error]="
                  productForm.get('price')?.invalid && productForm.get('price')?.touched
                "
                placeholder="99.99"
                step="0.01"
              />
              <div
                class="error-message"
                *ngIf="productForm.get('price')?.invalid && productForm.get('price')?.touched"
              >
                Price must be a positive number
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="description">Description</label>
            <textarea
              id="description"
              formControlName="description"
              class="form-control"
              rows="4"
              placeholder="Product description..."
            ></textarea>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="discount_percentage">Discount %</label>
              <input
                type="number"
                id="discount_percentage"
                formControlName="discount_percentage"
                class="form-control"
                placeholder="0"
                min="0"
                max="100"
              />
            </div>

            <div class="form-group">
              <label for="initial_quantity">Initial Quantity *</label>
              <input
                type="number"
                id="initial_quantity"
                formControlName="initial_quantity"
                class="form-control"
                [class.error]="
                  productForm.get('initial_quantity')?.invalid &&
                  productForm.get('initial_quantity')?.touched
                "
                placeholder="100"
                min="0"
              />
              <div
                class="error-message"
                *ngIf="
                  productForm.get('initial_quantity')?.invalid &&
                  productForm.get('initial_quantity')?.touched
                "
              >
                Quantity must be 0 or greater
              </div>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="gender_id">Gender</label>
              <select id="gender_id" formControlName="gender_id" class="form-control">
                <option [ngValue]="null">Select Gender</option>
                <option *ngFor="let gender of genders" [value]="gender.id">
                  {{ gender.name }}
                </option>
              </select>
            </div>

            <div class="form-group">
              <label for="category_id">Category</label>
              <select id="category_id" formControlName="category_id" class="form-control">
                <option [ngValue]="null">Select Category</option>
                <option *ngFor="let category of categories" [value]="category.id">
                  {{ category.name }}
                </option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="brand_id">Brand</label>
              <select id="brand_id" formControlName="brand_id" class="form-control">
                <option [ngValue]="null">Select Brand</option>
                <option *ngFor="let brand of brands" [value]="brand.id">{{ brand.name }}</option>
              </select>
            </div>

            <div class="form-group">
              <label for="size_id">Size</label>
              <select id="size_id" formControlName="size_id" class="form-control">
                <option [ngValue]="null">Select Size</option>
                <option *ngFor="let size of sizes" [value]="size.id">{{ size.name }}</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label for="color_id">Color</label>
            <select id="color_id" formControlName="color_id" class="form-control">
              <option [ngValue]="null">Select Color</option>
              <option *ngFor="let color of colors" [value]="color.id">{{ color.name }}</option>
            </select>
          </div>

          <div class="form-group" *ngIf="isEditMode">
            <label class="checkbox-label">
              <input type="checkbox" formControlName="is_active" />
              <span>Active Product</span>
            </label>
          </div>

          <div class="error-message" *ngIf="errorMessage">
            {{ errorMessage }}
          </div>

          <div class="form-actions">
            <button type="button" class="btn btn-secondary" routerLink="/products">Cancel</button>
            <button
              type="submit"
              class="btn btn-primary"
              [disabled]="productForm.invalid || loading"
            >
              <span *ngIf="!loading">{{ isEditMode ? 'Update' : 'Create' }} Product</span>
              <span *ngIf="loading">Saving...</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 900px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .form-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
      }

      .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }

      .form-group {
        margin-bottom: 20px;
      }

      .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #333;
        font-weight: 500;
        font-size: 14px;
      }

      .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
        box-sizing: border-box;
      }

      .form-control:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
      }

      .form-control.error {
        border-color: #e74c3c;
      }

      textarea.form-control {
        resize: vertical;
        font-family: inherit;
      }

      .checkbox-label {
        display: flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
      }

      .checkbox-label input[type='checkbox'] {
        width: 18px;
        height: 18px;
        cursor: pointer;
      }

      .error-message {
        color: #e74c3c;
        font-size: 13px;
        margin-top: 6px;
      }

      .form-actions {
        display: flex;
        gap: 15px;
        justify-content: flex-end;
        margin-top: 30px;
        padding-top: 30px;
        border-top: 1px solid #eee;
      }

      .btn {
        padding: 12px 30px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 15px;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover:not(:disabled) {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    `,
  ],
})
export class ProductFormComponent implements OnInit {
  productForm: FormGroup;
  categories: Category[] = [];
  brands: Brand[] = [];
  genders: Gender[] = [];
  sizes: Size[] = [];
  colors: Color[] = [];
  loading = false;
  errorMessage = '';
  isEditMode = false;
  productId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private genericService: GenericService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      price: [0, [Validators.required, Validators.min(0)]],
      discount_percentage: [0, [Validators.min(0), Validators.max(100)]],
      initial_quantity: [0, [Validators.required, Validators.min(0)]],
      gender_id: [null],
      category_id: [null],
      brand_id: [null],
      size_id: [null],
      color_id: [null],
      is_active: [true],
    });
  }

  ngOnInit(): void {
    this.loadFiltersData();
    this.route.params.subscribe((params) => {
      if (params['id']) {
        this.isEditMode = true;
        this.productId = +params['id'];
        this.loadProduct(this.productId);
      }
    });
  }

  loadFiltersData(): void {
    this.genericService.getCategories().subscribe((res) => (this.categories = res.categories));
    this.genericService.getBrands().subscribe((res) => (this.brands = res.brands));
    this.genericService.getGenders().subscribe((res) => (this.genders = res.genders));
    this.genericService.getSizes().subscribe((res) => (this.sizes = res.sizes));
    this.genericService.getColors().subscribe((res) => (this.colors = res.colors));
  }

  loadProduct(id: number): void {
    this.productService.getById(id).subscribe({
      next: (response) => {
        this.productForm.patchValue(response.product);
      },
    });
  }

  onSubmit(): void {
    if (this.productForm.valid) {
      this.loading = true;
      this.errorMessage = '';

      const formData = { ...this.productForm.value };
      Object.keys(formData).forEach((key) => {
        if (formData[key] === null || formData[key] === '') {
          delete formData[key];
        }
      });

      const request = this.isEditMode
        ? this.productService.update(this.productId!, formData)
        : this.productService.create(formData);

      request.subscribe({
        next: () => {
          this.router.navigate(['/products']);
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.error?.error || 'Failed to save product';
        },
      });
    }
  }
}
