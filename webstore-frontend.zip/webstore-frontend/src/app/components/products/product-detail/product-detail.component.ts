import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { NavbarComponent } from '../../navbar/navbar.component';
import { ProductService } from '../../../services/product.service';
import { AuthService } from '../../../services/auth.service';
import { Product, ProductQuantity } from '../../../models/product.model';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Product Details</h1>
        <div class="actions">
          <a [routerLink]="['/products/edit', product.id]" class="btn btn-primary" *ngIf="product"
            >Edit</a
          >
          <button
            (click)="deleteProduct()"
            class="btn btn-danger"
            *ngIf="product && hasRole('admin')"
          >
            Delete
          </button>
          <a routerLink="/products" class="btn btn-secondary">Back to List</a>
        </div>
      </div>

      <div class="detail-card" *ngIf="product && !loading">
        <div class="product-image">
          <span class="product-placeholder">{{ product.name.charAt(0) }}</span>
          <div class="product-badge" *ngIf="product.discount_percentage > 0">
            -{{ product.discount_percentage }}%
          </div>
        </div>

        <div class="product-info">
          <h2>{{ product.name }}</h2>
          <p class="description">{{ product.description || 'No description available' }}</p>

          <div class="info-grid">
            <div class="info-item">
              <span class="info-label">Price</span>
              <span class="info-value price">
                \${{ product.discounted_price }}
                <span class="original-price" *ngIf="product.discount_percentage > 0"
                  >\${{ product.price }}</span
                >
              </span>
            </div>

            <div class="info-item">
              <span class="info-label">Discount</span>
              <span class="info-value">{{ product.discount_percentage }}%</span>
            </div>

            <div class="info-item">
              <span class="info-label">Initial Quantity</span>
              <span class="info-value">{{ product.initial_quantity }}</span>
            </div>

            <div class="info-item" *ngIf="quantity">
              <span class="info-label">Current Stock</span>
              <span class="info-value" [class.out-of-stock]="quantity.current_quantity === 0">
                {{ quantity.current_quantity }}
              </span>
            </div>

            <div class="info-item" *ngIf="quantity">
              <span class="info-label">Sold Quantity</span>
              <span class="info-value">{{ quantity.sold_quantity }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Gender</span>
              <span class="info-value">{{ product.gender_name || 'N/A' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Category</span>
              <span class="info-value">{{ product.category_name || 'N/A' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Brand</span>
              <span class="info-value">{{ product.brand_name || 'N/A' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Size</span>
              <span class="info-value">{{ product.size_name || 'N/A' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Color</span>
              <span class="info-value">{{ product.color_name || 'N/A' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Status</span>
              <span class="info-value">
                <span class="status-badge" [class.active]="product.is_active">
                  {{ product.is_active ? 'Active' : 'Inactive' }}
                </span>
              </span>
            </div>

            <div class="info-item">
              <span class="info-label">Created</span>
              <span class="info-value">{{ product.created_at | date : 'medium' }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="loading" *ngIf="loading">Loading product details...</div>
      <div class="error" *ngIf="error">{{ error }}</div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .actions {
        display: flex;
        gap: 10px;
      }

      .detail-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        display: grid;
        grid-template-columns: 400px 1fr;
        gap: 30px;
      }

      .product-image {
        height: 400px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
      }

      .product-placeholder {
        font-size: 120px;
        color: white;
        font-weight: 700;
      }

      .product-badge {
        position: absolute;
        top: 20px;
        right: 20px;
        background: #e53e3e;
        color: white;
        padding: 8px 16px;
        border-radius: 20px;
        font-size: 16px;
        font-weight: 600;
      }

      .product-info {
        padding: 30px;
      }

      .product-info h2 {
        font-size: 32px;
        color: #333;
        margin: 0 0 15px 0;
      }

      .description {
        color: #666;
        font-size: 16px;
        line-height: 1.6;
        margin: 0 0 30px 0;
      }

      .info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
      }

      .info-item {
        display: flex;
        flex-direction: column;
        gap: 5px;
      }

      .info-label {
        font-size: 13px;
        color: #999;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.5px;
      }

      .info-value {
        font-size: 18px;
        color: #333;
        font-weight: 600;
      }

      .info-value.price {
        font-size: 28px;
        color: #667eea;
      }

      .info-value.out-of-stock {
        color: #e53e3e;
      }

      .original-price {
        font-size: 18px;
        color: #999;
        text-decoration: line-through;
        margin-left: 10px;
      }

      .status-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 14px;
        background: #e2e8f0;
        color: #666;
      }

      .status-badge.active {
        background: #c6f6d5;
        color: #22543d;
      }

      .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn-danger {
        background: #e53e3e;
        color: white;
      }

      .btn-danger:hover {
        background: #c53030;
      }

      .loading,
      .error {
        text-align: center;
        padding: 40px;
        color: #666;
      }

      .error {
        background: #fee;
        color: #c33;
        border-radius: 8px;
      }

      @media (max-width: 768px) {
        .detail-card {
          grid-template-columns: 1fr;
        }

        .info-grid {
          grid-template-columns: 1fr;
        }
      }
    `,
  ],
})
export class ProductDetailComponent implements OnInit {
  product: Product | null = null;
  quantity: ProductQuantity | null = null;
  loading = true;
  error = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      const id = +params['id'];
      this.loadProduct(id);
      this.loadQuantity(id);
    });
  }

  loadProduct(id: number): void {
    this.productService.getById(id).subscribe({
      next: (response) => {
        this.product = response.product;
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to load product';
        this.loading = false;
      },
    });
  }

  loadQuantity(id: number): void {
    this.productService.getQuantity(id).subscribe({
      next: (data) => {
        this.quantity = data;
      },
    });
  }

  deleteProduct(): void {
    if (this.product && confirm('Are you sure you want to delete this product?')) {
      this.productService.delete(this.product.id).subscribe({
        next: () => {
          this.router.navigate(['/products']);
        },
        error: (error) => {
          this.error = 'Failed to delete product';
        },
      });
    }
  }

  hasRole(...roles: string[]): boolean {
    return this.authService.hasRole(...roles);
  }
}
