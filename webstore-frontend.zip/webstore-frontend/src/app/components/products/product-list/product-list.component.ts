import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../../navbar/navbar.component';
import { ProductService } from '../../../services/product.service';
import { GenericService } from '../../../services/generic.service';
import { AuthService } from '../../../services/auth.service';
import { Product } from '../../../models/product.model';
import { Category, Brand, Gender, Size, Color } from '../../../models/generic.model';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Products</h1>
        <a routerLink="/products/create" class="btn btn-primary">Add Product</a>
      </div>

      <div class="filters-section">
        <h3>Filters</h3>
        <div class="filters-grid">
          <select [(ngModel)]="filters.gender" (change)="applyFilters()" class="form-control">
            <option value="">All Genders</option>
            <option *ngFor="let gender of genders" [value]="gender.name">{{ gender.name }}</option>
          </select>

          <select [(ngModel)]="filters.category" (change)="applyFilters()" class="form-control">
            <option value="">All Categories</option>
            <option *ngFor="let category of categories" [value]="category.name">
              {{ category.name }}
            </option>
          </select>

          <select [(ngModel)]="filters.brand" (change)="applyFilters()" class="form-control">
            <option value="">All Brands</option>
            <option *ngFor="let brand of brands" [value]="brand.name">{{ brand.name }}</option>
          </select>

          <select [(ngModel)]="filters.size" (change)="applyFilters()" class="form-control">
            <option value="">All Sizes</option>
            <option *ngFor="let size of sizes" [value]="size.name">{{ size.name }}</option>
          </select>

          <select [(ngModel)]="filters.color" (change)="applyFilters()" class="form-control">
            <option value="">All Colors</option>
            <option *ngFor="let color of colors" [value]="color.name">{{ color.name }}</option>
          </select>

          <select [(ngModel)]="filters.availability" (change)="applyFilters()" class="form-control">
            <option value="">All</option>
            <option value="in_stock">In Stock</option>
            <option value="out_of_stock">Out of Stock</option>
          </select>

          <input
            type="number"
            [(ngModel)]="filters.price_min"
            (change)="applyFilters()"
            placeholder="Min Price"
            class="form-control"
          />

          <input
            type="number"
            [(ngModel)]="filters.price_max"
            (change)="applyFilters()"
            placeholder="Max Price"
            class="form-control"
          />

          <button (click)="clearFilters()" class="btn btn-secondary">Clear Filters</button>
        </div>
      </div>

      <div class="products-grid" *ngIf="!loading">
        <div class="product-card" *ngFor="let product of products">
          <div class="product-image">
            <span class="product-placeholder">{{ product.name.charAt(0) }}</span>
            <div class="product-badge" *ngIf="product.discount_percentage > 0">
              -{{ product.discount_percentage }}%
            </div>
            <div class="product-stock" [class.out-of-stock]="product.current_quantity === 0">
              {{ product.current_quantity || 0 }} in stock
            </div>
          </div>
          <div class="product-content">
            <h3>{{ product.name }}</h3>
            <p class="product-description">{{ product.description || 'No description' }}</p>
            <div class="product-details">
              <span class="badge" *ngIf="product.gender_name">{{ product.gender_name }}</span>
              <span class="badge" *ngIf="product.category_name">{{ product.category_name }}</span>
              <span class="badge" *ngIf="product.brand_name">{{ product.brand_name }}</span>
            </div>
            <div class="product-price">
              <span class="price-current">\${{ product.discounted_price }}</span>
              <span class="price-original" *ngIf="product.discount_percentage > 0"
                >\${{ product.price }}</span
              >
            </div>
            <div class="product-actions">
              <a [routerLink]="['/products', product.id]" class="btn btn-sm btn-outline">View</a>
              <a [routerLink]="['/products/edit', product.id]" class="btn btn-sm btn-primary"
                >Edit</a
              >
              <button
                (click)="deleteProduct(product.id)"
                class="btn btn-sm btn-danger"
                *ngIf="hasRole('admin')"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="pagination" *ngIf="pagination">
        <button
          (click)="changePage(pagination.page - 1)"
          [disabled]="pagination.page === 1"
          class="btn btn-secondary"
        >
          Previous
        </button>
        <span class="page-info">
          Page {{ pagination.page }} of {{ pagination.totalPages }} ({{ pagination.total }} total)
        </span>
        <button
          (click)="changePage(pagination.page + 1)"
          [disabled]="pagination.page === pagination.totalPages"
          class="btn btn-secondary"
        >
          Next
        </button>
      </div>

      <div class="loading" *ngIf="loading">Loading products...</div>
      <div class="empty" *ngIf="!loading && products.length === 0">
        No products found. <a routerLink="/products/create">Create one</a>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .filters-section {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 30px;
      }

      .filters-section h3 {
        margin: 0 0 15px 0;
        font-size: 18px;
        color: #333;
      }

      .filters-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 15px;
      }

      .form-control {
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
      }

      .products-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
      }

      .product-card {
        background: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
      }

      .product-card:hover {
        transform: translateY(-5px);
      }

      .product-image {
        height: 200px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
      }

      .product-placeholder {
        font-size: 72px;
        color: white;
        font-weight: 700;
      }

      .product-badge {
        position: absolute;
        top: 10px;
        right: 10px;
        background: #e53e3e;
        color: white;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
      }

      .product-stock {
        position: absolute;
        bottom: 10px;
        right: 10px;
        background: #48bb78;
        color: white;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
      }

      .product-stock.out-of-stock {
        background: #e53e3e;
      }

      .product-content {
        padding: 20px;
      }

      .product-content h3 {
        font-size: 18px;
        margin: 0 0 10px 0;
        color: #333;
      }

      .product-description {
        color: #666;
        font-size: 14px;
        margin: 0 0 15px 0;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }

      .product-details {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 15px;
      }

      .badge {
        background: #f5f6ff;
        color: #667eea;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 500;
      }

      .product-price {
        margin-bottom: 15px;
      }

      .price-current {
        font-size: 24px;
        font-weight: 700;
        color: #333;
      }

      .price-original {
        font-size: 16px;
        color: #999;
        text-decoration: line-through;
        margin-left: 10px;
      }

      .product-actions {
        display: flex;
        gap: 10px;
      }

      .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        text-align: center;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn-danger {
        background: #e53e3e;
        color: white;
      }

      .btn-danger:hover {
        background: #c53030;
      }

      .btn-outline {
        background: transparent;
        border: 1px solid #667eea;
        color: #667eea;
      }

      .btn-outline:hover {
        background: #667eea;
        color: white;
      }

      .btn-sm {
        padding: 8px 16px;
        font-size: 14px;
        flex: 1;
      }

      .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 20px;
        padding: 20px;
      }

      .page-info {
        color: #666;
        font-size: 14px;
      }

      .loading,
      .empty {
        text-align: center;
        padding: 40px;
        color: #666;
      }

      .empty a {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
      }
    `,
  ],
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  categories: Category[] = [];
  brands: Brand[] = [];
  genders: Gender[] = [];
  sizes: Size[] = [];
  colors: Color[] = [];
  loading = true;
  pagination: any = null;

  filters = {
    gender: '',
    category: '',
    brand: '',
    size: '',
    color: '',
    availability: '',
    price_min: undefined,
    price_max: undefined,
    page: 1,
    limit: 20,
  };

  constructor(
    private productService: ProductService,
    private genericService: GenericService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadFiltersData();
    this.loadProducts();
  }

  loadFiltersData(): void {
    this.genericService.getCategories().subscribe((res) => (this.categories = res.categories));
    this.genericService.getBrands().subscribe((res) => (this.brands = res.brands));
    this.genericService.getGenders().subscribe((res) => (this.genders = res.genders));
    this.genericService.getSizes().subscribe((res) => (this.sizes = res.sizes));
    this.genericService.getColors().subscribe((res) => (this.colors = res.colors));
  }

  loadProducts(): void {
    this.loading = true;
    const params: any = { ...this.filters };
    Object.keys(params).forEach((key) => {
      if (params[key] === '' || params[key] === undefined) {
        delete params[key];
      }
    });

    this.productService.search(params).subscribe({
      next: (response) => {
        this.products = response.products;
        this.pagination = response.pagination;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }

  applyFilters(): void {
    this.filters.page = 1;
    this.loadProducts();
  }

  clearFilters(): void {
    this.filters = {
      gender: '',
      category: '',
      brand: '',
      size: '',
      color: '',
      availability: '',
      price_min: undefined,
      price_max: undefined,
      page: 1,
      limit: 20,
    };
    this.loadProducts();
  }

  changePage(page: number): void {
    this.filters.page = page;
    this.loadProducts();
  }

  deleteProduct(id: number): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.productService.delete(id).subscribe({
        next: () => {
          this.loadProducts();
        },
      });
    }
  }

  hasRole(...roles: string[]): boolean {
    return this.authService.hasRole(...roles);
  }
}
