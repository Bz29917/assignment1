import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Settings</h1>
      </div>

      <div class="settings-grid">
        <div class="settings-card">
          <h2>Profile Information</h2>
          <div class="info-section" *ngIf="currentUser">
            <div class="info-row">
              <span class="label">Username:</span>
              <span class="value">{{ currentUser.username }}</span>
            </div>
            <div class="info-row">
              <span class="label">Email:</span>
              <span class="value">{{ currentUser.email }}</span>
            </div>
            <div class="info-row">
              <span class="label">Role:</span>
              <span class="value">
                <span class="role-badge">{{ currentUser.role }}</span>
              </span>
            </div>
            <div class="info-row">
              <span class="label">Name:</span>
              <span class="value">{{ currentUser.first_name }} {{ currentUser.last_name }}</span>
            </div>
            <div class="info-row">
              <span class="label">Status:</span>
              <span class="value">
                <span class="status-badge" [class.active]="currentUser.is_active">
                  {{ currentUser.is_active ? 'Active' : 'Inactive' }}
                </span>
              </span>
            </div>
            <div class="info-row">
              <span class="label">Last Login:</span>
              <span class="value">{{
                currentUser.last_login ? (currentUser.last_login | date : 'medium') : 'Never'
              }}</span>
            </div>
          </div>
        </div>

        <div class="settings-card">
          <h2>Change Password</h2>
          <form [formGroup]="passwordForm" (ngSubmit)="onChangePassword()">
            <div class="form-group">
              <label for="oldPassword">Current Password</label>
              <input
                type="password"
                id="oldPassword"
                formControlName="oldPassword"
                class="form-control"
                [class.error]="
                  passwordForm.get('oldPassword')?.invalid &&
                  passwordForm.get('oldPassword')?.touched
                "
                placeholder="Enter current password"
              />
              <div
                class="error-message"
                *ngIf="
                  passwordForm.get('oldPassword')?.invalid &&
                  passwordForm.get('oldPassword')?.touched
                "
              >
                Current password is required
              </div>
            </div>

            <div class="form-group">
              <label for="newPassword">New Password</label>
              <input
                type="password"
                id="newPassword"
                formControlName="newPassword"
                class="form-control"
                [class.error]="
                  passwordForm.get('newPassword')?.invalid &&
                  passwordForm.get('newPassword')?.touched
                "
                placeholder="Enter new password"
              />
              <div
                class="error-message"
                *ngIf="
                  passwordForm.get('newPassword')?.invalid &&
                  passwordForm.get('newPassword')?.touched
                "
              >
                Password must be at least 6 characters
              </div>
            </div>

            <div class="success-message" *ngIf="successMessage">
              {{ successMessage }}
            </div>

            <div class="error-message" *ngIf="errorMessage">
              {{ errorMessage }}
            </div>

            <button
              type="submit"
              class="btn btn-primary"
              [disabled]="passwordForm.invalid || loading"
            >
              <span *ngIf="!loading">Change Password</span>
              <span *ngIf="loading">Changing...</span>
            </button>
          </form>
        </div>
      </div>

      <div class="settings-card full-width">
        <h2>Application Information</h2>
        <div class="app-info">
          <div class="app-info-item">
            <h3>Web Store Management System</h3>
            <p>Version 1.0.0</p>
          </div>
          <div class="app-info-item">
            <h3>Features</h3>
            <ul>
              <li>Product Management with Advanced Filtering</li>
              <li>Order Processing & Tracking</li>
              <li>Client Management</li>
              <li>User Management (Admin Only)</li>
              <li>Real-time Stock Management</li>
              <li>Comprehensive Reports & Analytics</li>
              <li>Role-based Access Control</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .settings-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
      }

      .settings-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
      }

      .settings-card.full-width {
        grid-column: 1 / -1;
      }

      .settings-card h2 {
        margin: 0 0 20px 0;
        font-size: 20px;
        color: #333;
        padding-bottom: 15px;
        border-bottom: 2px solid #eee;
      }

      .info-section {
        display: grid;
        gap: 15px;
      }

      .info-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #f5f5f5;
      }

      .info-row:last-child {
        border-bottom: none;
      }

      .label {
        font-weight: 600;
        color: #666;
        font-size: 14px;
      }

      .value {
        color: #333;
        font-size: 14px;
        text-align: right;
      }

      .role-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        background: #e0e7ff;
        color: #3730a3;
      }

      .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        background: #fee2e2;
        color: #991b1b;
      }

      .status-badge.active {
        background: #d1fae5;
        color: #065f46;
      }

      .form-group {
        margin-bottom: 20px;
      }

      .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #333;
        font-weight: 500;
        font-size: 14px;
      }

      .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
        box-sizing: border-box;
      }

      .form-control:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
      }

      .form-control.error {
        border-color: #e74c3c;
      }

      .error-message {
        color: #e74c3c;
        font-size: 13px;
        margin-top: 6px;
        background: #fee;
        padding: 10px;
        border-radius: 8px;
      }

      .success-message {
        background: #d4edda;
        color: #155724;
        padding: 12px;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 14px;
      }

      .btn {
        padding: 12px 30px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 15px;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover:not(:disabled) {
        background: #5568d3;
      }

      .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .app-info {
        display: grid;
        gap: 20px;
      }

      .app-info-item h3 {
        margin: 0 0 10px 0;
        font-size: 18px;
        color: #333;
      }

      .app-info-item p {
        margin: 0;
        color: #666;
      }

      .app-info-item ul {
        margin: 10px 0;
        padding-left: 20px;
      }

      .app-info-item li {
        color: #666;
        margin-bottom: 8px;
      }
    `,
  ],
})
export class SettingsComponent implements OnInit {
  currentUser: User | null = null;
  passwordForm: FormGroup;
  loading = false;
  errorMessage = '';
  successMessage = '';

  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.passwordForm = this.fb.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  ngOnInit(): void {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user;
    });
  }

  onChangePassword(): void {
    if (this.passwordForm.valid) {
      this.loading = true;
      this.errorMessage = '';
      this.successMessage = '';

      this.authService.changePassword(this.passwordForm.value).subscribe({
        next: (response) => {
          this.loading = false;
          this.successMessage = 'Password changed successfully!';
          this.passwordForm.reset();
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.error?.error || 'Failed to change password';
        },
      });
    }
  }
}
