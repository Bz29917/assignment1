import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../navbar/navbar.component';
import { ClientService } from '../../../services/client.service';

@Component({
  selector: 'app-client-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>{{ isEditMode ? 'Edit Client' : 'Add Client' }}</h1>
      </div>

      <div class="form-card">
        <form [formGroup]="clientForm" (ngSubmit)="onSubmit()">
          <div class="form-row">
            <div class="form-group">
              <label for="first_name">First Name *</label>
              <input
                type="text"
                id="first_name"
                formControlName="first_name"
                class="form-control"
                [class.error]="
                  clientForm.get('first_name')?.invalid && clientForm.get('first_name')?.touched
                "
                placeholder="John"
              />
              <div
                class="error-message"
                *ngIf="
                  clientForm.get('first_name')?.invalid && clientForm.get('first_name')?.touched
                "
              >
                First name is required
              </div>
            </div>

            <div class="form-group">
              <label for="last_name">Last Name *</label>
              <input
                type="text"
                id="last_name"
                formControlName="last_name"
                class="form-control"
                [class.error]="
                  clientForm.get('last_name')?.invalid && clientForm.get('last_name')?.touched
                "
                placeholder="Doe"
              />
              <div
                class="error-message"
                *ngIf="clientForm.get('last_name')?.invalid && clientForm.get('last_name')?.touched"
              >
                Last name is required
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="email">Email *</label>
            <input
              type="email"
              id="email"
              formControlName="email"
              class="form-control"
              [class.error]="clientForm.get('email')?.invalid && clientForm.get('email')?.touched"
              placeholder="john@example.com"
            />
            <div
              class="error-message"
              *ngIf="clientForm.get('email')?.invalid && clientForm.get('email')?.touched"
            >
              <span *ngIf="clientForm.get('email')?.errors?.['required']">Email is required</span>
              <span *ngIf="clientForm.get('email')?.errors?.['email']">Invalid email format</span>
            </div>
          </div>

          <div class="form-group">
            <label for="phone">Phone</label>
            <input
              type="text"
              id="phone"
              formControlName="phone"
              class="form-control"
              placeholder="+1234567890"
            />
          </div>

          <div class="form-group">
            <label for="address">Address</label>
            <textarea
              id="address"
              formControlName="address"
              class="form-control"
              rows="3"
              placeholder="Street address..."
            ></textarea>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="city">City</label>
              <input
                type="text"
                id="city"
                formControlName="city"
                class="form-control"
                placeholder="New York"
              />
            </div>

            <div class="form-group">
              <label for="country">Country</label>
              <input
                type="text"
                id="country"
                formControlName="country"
                class="form-control"
                placeholder="USA"
              />
            </div>
          </div>

          <div class="form-group">
            <label for="postal_code">Postal Code</label>
            <input
              type="text"
              id="postal_code"
              formControlName="postal_code"
              class="form-control"
              placeholder="10001"
            />
          </div>

          <div class="error-message" *ngIf="errorMessage">
            {{ errorMessage }}
          </div>

          <div class="form-actions">
            <button type="button" class="btn btn-secondary" routerLink="/clients">Cancel</button>
            <button
              type="submit"
              class="btn btn-primary"
              [disabled]="clientForm.invalid || loading"
            >
              <span *ngIf="!loading">{{ isEditMode ? 'Update' : 'Create' }} Client</span>
              <span *ngIf="loading">Saving...</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 900px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .form-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
      }

      .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }

      .form-group {
        margin-bottom: 20px;
      }

      .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #333;
        font-weight: 500;
        font-size: 14px;
      }

      .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
        box-sizing: border-box;
      }

      .form-control:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
      }

      .form-control.error {
        border-color: #e74c3c;
      }

      textarea.form-control {
        resize: vertical;
        font-family: inherit;
      }

      .error-message {
        color: #e74c3c;
        font-size: 13px;
        margin-top: 6px;
      }

      .form-actions {
        display: flex;
        gap: 15px;
        justify-content: flex-end;
        margin-top: 30px;
        padding-top: 30px;
        border-top: 1px solid #eee;
      }

      .btn {
        padding: 12px 30px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 15px;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover:not(:disabled) {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    `,
  ],
})
export class ClientFormComponent implements OnInit {
  clientForm: FormGroup;
  loading = false;
  errorMessage = '';
  isEditMode = false;
  clientId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private clientService: ClientService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.clientForm = this.fb.group({
      first_name: ['', Validators.required],
      last_name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      address: [''],
      city: [''],
      country: [''],
      postal_code: [''],
    });
  }

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      if (params['id']) {
        this.isEditMode = true;
        this.clientId = +params['id'];
        this.loadClient(this.clientId);
      }
    });
  }

  loadClient(id: number): void {
    this.clientService.getById(id).subscribe({
      next: (response) => {
        this.clientForm.patchValue(response.client);
      },
    });
  }

  onSubmit(): void {
    if (this.clientForm.valid) {
      this.loading = true;
      this.errorMessage = '';

      const request = this.isEditMode
        ? this.clientService.update(this.clientId!, this.clientForm.value)
        : this.clientService.create(this.clientForm.value);

      request.subscribe({
        next: () => {
          this.router.navigate(['/clients']);
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.error?.error || 'Failed to save client';
        },
      });
    }
  }
}
