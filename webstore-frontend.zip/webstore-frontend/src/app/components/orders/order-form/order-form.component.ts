import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../navbar/navbar.component';
import { OrderService } from '../../../services/order.service';
import { ClientService } from '../../../services/client.service';
import { ProductService } from '../../../services/product.service';
import { Client } from '../../../models/client.model';
import { Product } from '../../../models/product.model';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Create Order</h1>
      </div>

      <div class="form-card">
        <form [formGroup]="orderForm" (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label for="client_id">Client *</label>
            <select
              id="client_id"
              formControlName="client_id"
              class="form-control"
              [class.error]="
                orderForm.get('client_id')?.invalid && orderForm.get('client_id')?.touched
              "
            >
              <option [ngValue]="null">Select Client</option>
              <option *ngFor="let client of clients" [value]="client.id">
                {{ client.first_name }} {{ client.last_name }} ({{ client.email }})
              </option>
            </select>
            <div
              class="error-message"
              *ngIf="orderForm.get('client_id')?.invalid && orderForm.get('client_id')?.touched"
            >
              Client is required
            </div>
          </div>

          <div class="items-section">
            <div class="items-header">
              <h3>Order Items</h3>
              <button type="button" (click)="addItem()" class="btn btn-secondary">Add Item</button>
            </div>

            <div formArrayName="items">
              <div
                *ngFor="let item of items.controls; let i = index"
                [formGroupName]="i"
                class="item-row"
              >
                <div class="form-group">
                  <label>Product *</label>
                  <select formControlName="product_id" class="form-control">
                    <option [ngValue]="null">Select Product</option>
                    <option *ngFor="let product of products" [value]="product.id">
                      {{ product.name }} (\${{ product.discounted_price }}) - Stock:
                      {{ product.current_quantity }}
                    </option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Quantity *</label>
                  <input
                    type="number"
                    formControlName="quantity"
                    class="form-control"
                    min="1"
                    placeholder="1"
                  />
                </div>

                <button type="button" (click)="removeItem(i)" class="btn btn-danger btn-icon">
                  ×
                </button>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="notes">Notes</label>
            <textarea
              id="notes"
              formControlName="notes"
              class="form-control"
              rows="3"
              placeholder="Optional order notes..."
            ></textarea>
          </div>

          <div class="error-message" *ngIf="errorMessage">
            {{ errorMessage }}
          </div>

          <div class="form-actions">
            <button type="button" class="btn btn-secondary" routerLink="/orders">Cancel</button>
            <button type="submit" class="btn btn-primary" [disabled]="orderForm.invalid || loading">
              <span *ngIf="!loading">Create Order</span>
              <span *ngIf="loading">Creating...</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 900px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .form-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
      }

      .form-group {
        margin-bottom: 20px;
      }

      .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #333;
        font-weight: 500;
        font-size: 14px;
      }

      .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
        box-sizing: border-box;
      }

      .form-control:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
      }

      .form-control.error {
        border-color: #e74c3c;
      }

      textarea.form-control {
        resize: vertical;
        font-family: inherit;
      }

      .items-section {
        margin: 30px 0;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
      }

      .items-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
      }

      .items-header h3 {
        margin: 0;
        font-size: 20px;
        color: #333;
      }

      .item-row {
        display: grid;
        grid-template-columns: 2fr 1fr auto;
        gap: 15px;
        margin-bottom: 15px;
        padding: 15px;
        background: white;
        border-radius: 8px;
      }

      .btn-icon {
        width: 40px;
        height: 40px;
        padding: 0;
        font-size: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: 28px;
      }

      .error-message {
        color: #e74c3c;
        font-size: 13px;
        margin-top: 6px;
        background: #fee;
        padding: 10px;
        border-radius: 8px;
      }

      .form-actions {
        display: flex;
        gap: 15px;
        justify-content: flex-end;
        margin-top: 30px;
        padding-top: 30px;
        border-top: 1px solid #eee;
      }

      .btn {
        padding: 12px 30px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 15px;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover:not(:disabled) {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn-danger {
        background: #e53e3e;
        color: white;
      }

      .btn-danger:hover {
        background: #c53030;
      }

      .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    `,
  ],
})
export class OrderFormComponent implements OnInit {
  orderForm: FormGroup;
  clients: Client[] = [];
  products: Product[] = [];
  loading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private orderService: OrderService,
    private clientService: ClientService,
    private productService: ProductService,
    private router: Router
  ) {
    this.orderForm = this.fb.group({
      client_id: [null, Validators.required],
      items: this.fb.array([], Validators.required),
      notes: [''],
    });
  }

  get items(): FormArray {
    return this.orderForm.get('items') as FormArray;
  }

  ngOnInit(): void {
    this.loadClients();
    this.loadProducts();
    this.addItem();
  }

  loadClients(): void {
    this.clientService.getAll(1, 1000).subscribe({
      next: (response) => {
        this.clients = response.clients;
      },
    });
  }

  loadProducts(): void {
    this.productService.getAll(1, 1000).subscribe({
      next: (response) => {
        this.products = response.products;
      },
    });
  }

  addItem(): void {
    const itemGroup = this.fb.group({
      product_id: [null, Validators.required],
      quantity: [1, [Validators.required, Validators.min(1)]],
    });
    this.items.push(itemGroup);
  }

  removeItem(index: number): void {
    this.items.removeAt(index);
  }

  onSubmit(): void {
    if (this.orderForm.valid) {
      this.loading = true;
      this.errorMessage = '';

      this.orderService.create(this.orderForm.value).subscribe({
        next: () => {
          this.router.navigate(['/orders']);
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.error?.error || 'Failed to create order';
        },
      });
    }
  }
}
