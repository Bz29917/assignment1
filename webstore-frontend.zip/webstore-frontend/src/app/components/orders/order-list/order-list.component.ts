import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../../navbar/navbar.component';
import { OrderService } from '../../../services/order.service';
import { Order } from '../../../models/order.model';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Orders</h1>
        <a routerLink="/orders/create" class="btn btn-primary">Create Order</a>
      </div>

      <div class="filters">
        <select [(ngModel)]="statusFilter" (change)="applyFilter()" class="form-control">
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="confirmed">Confirmed</option>
          <option value="processing">Processing</option>
          <option value="shipped">Shipped</option>
          <option value="delivered">Delivered</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      <div class="orders-table" *ngIf="!loading">
        <table>
          <thead>
            <tr>
              <th>Order #</th>
              <th>Client</th>
              <th>Items</th>
              <th>Total</th>
              <th>Status</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let order of orders">
              <td>{{ order.order_number }}</td>
              <td>{{ order.first_name }} {{ order.last_name }}</td>
              <td>{{ order.items_count }}</td>
              <td>\${{ order.total_amount | number : '1.2-2' }}</td>
              <td>
                <span class="status-badge" [ngClass]="'status-' + order.status">
                  {{ order.status }}
                </span>
              </td>
              <td>{{ order.created_at | date : 'short' }}</td>
              <td>
                <a [routerLink]="['/orders', order.id]" class="btn btn-sm">View</a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="pagination" *ngIf="pagination">
        <button
          (click)="changePage(pagination.page - 1)"
          [disabled]="pagination.page === 1"
          class="btn btn-secondary"
        >
          Previous
        </button>
        <span class="page-info">
          Page {{ pagination.page }} of {{ pagination.totalPages }} ({{ pagination.total }} total)
        </span>
        <button
          (click)="changePage(pagination.page + 1)"
          [disabled]="pagination.page === pagination.totalPages"
          class="btn btn-secondary"
        >
          Next
        </button>
      </div>

      <div class="loading" *ngIf="loading">Loading orders...</div>
      <div class="empty" *ngIf="!loading && orders.length === 0">
        No orders found. <a routerLink="/orders/create">Create one</a>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .filters {
        margin-bottom: 20px;
      }

      .form-control {
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        max-width: 200px;
      }

      .orders-table {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        margin-bottom: 30px;
      }

      table {
        width: 100%;
        border-collapse: collapse;
      }

      thead {
        background: #f8f9fa;
      }

      th {
        padding: 15px;
        text-align: left;
        font-weight: 600;
        color: #333;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      td {
        padding: 15px;
        border-top: 1px solid #eee;
        color: #666;
      }

      tbody tr:hover {
        background: #f8f9fa;
      }

      .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
      }

      .status-pending {
        background: #fef3c7;
        color: #92400e;
      }

      .status-confirmed {
        background: #dbeafe;
        color: #1e40af;
      }

      .status-processing {
        background: #e0e7ff;
        color: #3730a3;
      }

      .status-shipped {
        background: #ddd6fe;
        color: #5b21b6;
      }

      .status-delivered {
        background: #d1fae5;
        color: #065f46;
      }

      .status-cancelled {
        background: #fee2e2;
        color: #991b1b;
      }

      .btn {
        padding: 8px 16px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s ease;
        font-size: 14px;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn-sm {
        padding: 6px 12px;
        background: #667eea;
        color: white;
      }

      .btn-sm:hover {
        background: #5568d3;
      }

      .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 20px;
        padding: 20px;
      }

      .page-info {
        color: #666;
        font-size: 14px;
      }

      .loading,
      .empty {
        text-align: center;
        padding: 40px;
        color: #666;
      }

      .empty a {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
      }
    `,
  ],
})
export class OrderListComponent implements OnInit {
  orders: Order[] = [];
  loading = true;
  pagination: any = null;
  statusFilter = '';

  constructor(private orderService: OrderService) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(page: number = 1): void {
    this.loading = true;
    this.orderService.getAll(page, 20, this.statusFilter || undefined).subscribe({
      next: (response) => {
        this.orders = response.orders;
        this.pagination = response.pagination;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }

  applyFilter(): void {
    this.loadOrders(1);
  }

  changePage(page: number): void {
    this.loadOrders(page);
  }
}
