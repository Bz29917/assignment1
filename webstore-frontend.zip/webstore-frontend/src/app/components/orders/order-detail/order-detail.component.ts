import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../../navbar/navbar.component';
import { OrderService } from '../../../services/order.service';
import { Order } from '../../../models/order.model';

@Component({
  selector: 'app-order-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Order Details</h1>
        <div class="actions">
          <button
            (click)="cancelOrder()"
            class="btn btn-danger"
            *ngIf="order && order.status !== 'cancelled' && order.status !== 'delivered'"
          >
            Cancel Order
          </button>
          <a routerLink="/orders" class="btn btn-secondary">Back to List</a>
        </div>
      </div>

      <div class="detail-grid" *ngIf="order && !loading">
        <div class="info-card">
          <h2>Order Information</h2>
          <div class="info-row">
            <span class="label">Order Number:</span>
            <span class="value">{{ order.order_number }}</span>
          </div>
          <div class="info-row">
            <span class="label">Status:</span>
            <span class="value">
              <span class="status-badge" [ngClass]="'status-' + order.status">
                {{ order.status }}
              </span>
            </span>
          </div>
          <div class="info-row">
            <span class="label">Total Amount:</span>
            <span class="value price">\${{ order.total_amount | number : '1.2-2' }}</span>
          </div>
          <div class="info-row">
            <span class="label">Created:</span>
            <span class="value">{{ order.created_at | date : 'medium' }}</span>
          </div>
          <div class="info-row" *ngIf="order.confirmed_at">
            <span class="label">Confirmed:</span>
            <span class="value">{{ order.confirmed_at | date : 'medium' }}</span>
          </div>
          <div class="info-row" *ngIf="order.shipped_at">
            <span class="label">Shipped:</span>
            <span class="value">{{ order.shipped_at | date : 'medium' }}</span>
          </div>
          <div class="info-row" *ngIf="order.delivered_at">
            <span class="label">Delivered:</span>
            <span class="value">{{ order.delivered_at | date : 'medium' }}</span>
          </div>
          <div class="info-row" *ngIf="order.notes">
            <span class="label">Notes:</span>
            <span class="value">{{ order.notes }}</span>
          </div>

          <div
            class="status-update"
            *ngIf="order.status !== 'cancelled' && order.status !== 'delivered'"
          >
            <label for="newStatus">Update Status:</label>
            <div class="status-controls">
              <select [(ngModel)]="newStatus" id="newStatus" class="form-control">
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
              </select>
              <button (click)="updateStatus()" class="btn btn-primary">Update</button>
            </div>
          </div>
        </div>

        <div class="info-card">
          <h2>Client Information</h2>
          <div class="info-row">
            <span class="label">Name:</span>
            <span class="value">{{ order.first_name }} {{ order.last_name }}</span>
          </div>
          <div class="info-row">
            <span class="label">Email:</span>
            <span class="value">{{ order.email }}</span>
          </div>
          <div class="info-row" *ngIf="order.phone">
            <span class="label">Phone:</span>
            <span class="value">{{ order.phone }}</span>
          </div>
          <div class="info-row" *ngIf="order.address">
            <span class="label">Address:</span>
            <span class="value">{{ order.address }}</span>
          </div>
          <div class="info-row" *ngIf="order.city">
            <span class="label">City:</span>
            <span class="value">{{ order.city }}</span>
          </div>
          <div class="info-row" *ngIf="order.country">
            <span class="label">Country:</span>
            <span class="value">{{ order.country }}</span>
          </div>
        </div>
      </div>

      <div class="items-card" *ngIf="order && order.items">
        <h2>Order Items</h2>
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let item of order.items">
              <td>{{ item.product_name }}</td>
              <td>{{ item.quantity }}</td>
              <td>\${{ item.unit_price | number : '1.2-2' }}</td>
              <td>\${{ item.total_price | number : '1.2-2' }}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3"><strong>Total</strong></td>
              <td>
                <strong>\${{ order.total_amount | number : '1.2-2' }}</strong>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div class="loading" *ngIf="loading">Loading order details...</div>
      <div class="error" *ngIf="error">{{ error }}</div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .actions {
        display: flex;
        gap: 10px;
      }

      .detail-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 30px;
      }

      .info-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
      }

      .info-card h2 {
        font-size: 20px;
        color: #333;
        margin: 0 0 20px 0;
        padding-bottom: 15px;
        border-bottom: 2px solid #eee;
      }

      .info-row {
        display: flex;
        justify-content: space-between;
        padding: 12px 0;
        border-bottom: 1px solid #f5f5f5;
      }

      .info-row:last-child {
        border-bottom: none;
      }

      .label {
        font-weight: 600;
        color: #666;
        font-size: 14px;
      }

      .value {
        color: #333;
        font-size: 14px;
        text-align: right;
      }

      .value.price {
        font-size: 20px;
        font-weight: 700;
        color: #667eea;
      }

      .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
      }

      .status-pending {
        background: #fef3c7;
        color: #92400e;
      }

      .status-confirmed {
        background: #dbeafe;
        color: #1e40af;
      }

      .status-processing {
        background: #e0e7ff;
        color: #3730a3;
      }

      .status-shipped {
        background: #ddd6fe;
        color: #5b21b6;
      }

      .status-delivered {
        background: #d1fae5;
        color: #065f46;
      }

      .status-cancelled {
        background: #fee2e2;
        color: #991b1b;
      }

      .status-update {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 2px solid #eee;
      }

      .status-update label {
        display: block;
        margin-bottom: 10px;
        font-weight: 600;
        color: #333;
      }

      .status-controls {
        display: flex;
        gap: 10px;
      }

      .items-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
      }

      .items-card h2 {
        font-size: 20px;
        color: #333;
        margin: 0 0 20px 0;
      }

      table {
        width: 100%;
        border-collapse: collapse;
      }

      thead {
        background: #f8f9fa;
      }

      th {
        padding: 12px;
        text-align: left;
        font-weight: 600;
        color: #333;
        font-size: 14px;
      }

      td {
        padding: 12px;
        border-top: 1px solid #eee;
        color: #666;
      }

      tfoot td {
        padding: 15px 12px;
        border-top: 2px solid #333;
        font-size: 16px;
      }

      .form-control {
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        flex: 1;
      }

      .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover {
        background: #5568d3;
      }

      .btn-secondary {
        background: #e2e8f0;
        color: #333;
      }

      .btn-secondary:hover {
        background: #cbd5e0;
      }

      .btn-danger {
        background: #e53e3e;
        color: white;
      }

      .btn-danger:hover {
        background: #c53030;
      }

      .loading,
      .error {
        text-align: center;
        padding: 40px;
        color: #666;
      }

      .error {
        background: #fee;
        color: #c33;
        border-radius: 8px;
      }

      @media (max-width: 768px) {
        .detail-grid {
          grid-template-columns: 1fr;
        }
      }
    `,
  ],
})
export class OrderDetailComponent implements OnInit {
  order: Order | null = null;
  loading = true;
  error = '';
  newStatus = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private orderService: OrderService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      const id = +params['id'];
      this.loadOrder(id);
    });
  }

  loadOrder(id: number): void {
    this.orderService.getById(id).subscribe({
      next: (response) => {
        this.order = response.order;
        this.newStatus = this.order.status;
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to load order';
        this.loading = false;
      },
    });
  }

  updateStatus(): void {
    if (this.order && this.newStatus) {
      this.orderService.updateStatus(this.order.id, this.newStatus).subscribe({
        next: () => {
          this.loadOrder(this.order!.id);
        },
        error: (error) => {
          this.error = 'Failed to update status';
        },
      });
    }
  }

  cancelOrder(): void {
    if (this.order && confirm('Are you sure you want to cancel this order?')) {
      this.orderService.cancel(this.order.id).subscribe({
        next: () => {
          this.loadOrder(this.order!.id);
        },
        error: (error) => {
          this.error = 'Failed to cancel order';
        },
      });
    }
  }
}
