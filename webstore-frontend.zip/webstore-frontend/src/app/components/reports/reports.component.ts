import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../navbar/navbar.component';
import { ReportService } from '../../services/report.service';
import {
  DailyEarnings,
  MonthlyEarnings,
  TopSellingProduct,
  SalesByCategory,
  SalesByBrand,
} from '../../models/report.model';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Reports & Analytics</h1>
      </div>

      <div class="reports-grid">
        <div class="report-card">
          <h3>Daily Earnings</h3>
          <input
            type="date"
            [(ngModel)]="selectedDate"
            (change)="loadDailyEarnings()"
            class="form-control"
          />
          <div class="report-content" *ngIf="dailyEarnings">
            <div class="metric">
              <span class="metric-label">Total Orders</span>
              <span class="metric-value">{{ dailyEarnings.total_orders }}</span>
            </div>
            <div class="metric">
              <span class="metric-label">Total Earnings</span>
              <span class="metric-value price"
                >\${{ dailyEarnings.total_earnings | number : '1.2-2' }}</span
              >
            </div>
            <div class="metric">
              <span class="metric-label">Avg Order Value</span>
              <span class="metric-value"
                >\${{ dailyEarnings.average_order_value | number : '1.2-2' }}</span
              >
            </div>
          </div>
        </div>

        <div class="report-card">
          <h3>Monthly Earnings</h3>
          <div class="form-row">
            <input
              type="number"
              [(ngModel)]="selectedYear"
              placeholder="Year"
              class="form-control"
            />
            <input
              type="number"
              [(ngModel)]="selectedMonth"
              placeholder="Month"
              class="form-control"
            />
            <button (click)="loadMonthlyEarnings()" class="btn btn-primary">Load</button>
          </div>
          <div class="report-content" *ngIf="monthlyEarnings">
            <div class="metric">
              <span class="metric-label">Total Orders</span>
              <span class="metric-value">{{ monthlyEarnings.total_orders }}</span>
            </div>
            <div class="metric">
              <span class="metric-label">Total Earnings</span>
              <span class="metric-value price"
                >\${{ monthlyEarnings.total_earnings | number : '1.2-2' }}</span
              >
            </div>
            <div class="metric">
              <span class="metric-label">Avg Order Value</span>
              <span class="metric-value"
                >\${{ monthlyEarnings.average_order_value | number : '1.2-2' }}</span
              >
            </div>
          </div>
        </div>
      </div>

      <div class="report-card full-width">
        <h3>Top Selling Products</h3>
        <div class="filters">
          <select [(ngModel)]="productPeriod" (change)="loadTopProducts()" class="form-control">
            <option value="">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
          <input
            type="number"
            [(ngModel)]="productLimit"
            (change)="loadTopProducts()"
            min="1"
            max="50"
            placeholder="Limit"
            class="form-control"
          />
        </div>
        <div class="table-container" *ngIf="topProducts.length > 0">
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Units Sold</th>
                <th>Revenue</th>
                <th>Orders</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let product of topProducts">
                <td>{{ product.name }}</td>
                <td>{{ product.category_name }}</td>
                <td>{{ product.brand_name }}</td>
                <td>{{ product.total_sold }}</td>
                <td>\${{ product.total_revenue | number : '1.2-2' }}</td>
                <td>{{ product.times_ordered }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="reports-grid">
        <div class="report-card">
          <h3>Sales by Category</h3>
          <select
            [(ngModel)]="categoryPeriod"
            (change)="loadSalesByCategory()"
            class="form-control"
          >
            <option value="">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
          <div class="list-container" *ngIf="salesByCategory.length > 0">
            <div class="list-item" *ngFor="let item of salesByCategory">
              <div class="list-item-header">
                <span class="list-item-name">{{ item.category_name }}</span>
                <span class="list-item-value">\${{ item.total_revenue | number : '1.2-2' }}</span>
              </div>
              <div class="list-item-meta">
                <span>{{ item.units_sold }} units</span>
                <span>{{ item.orders_count }} orders</span>
              </div>
            </div>
          </div>
        </div>

        <div class="report-card">
          <h3>Sales by Brand</h3>
          <select [(ngModel)]="brandPeriod" (change)="loadSalesByBrand()" class="form-control">
            <option value="">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
          <div class="list-container" *ngIf="salesByBrand.length > 0">
            <div class="list-item" *ngFor="let item of salesByBrand">
              <div class="list-item-header">
                <span class="list-item-name">{{ item.brand_name }}</span>
                <span class="list-item-value">\${{ item.total_revenue | number : '1.2-2' }}</span>
              </div>
              <div class="list-item-meta">
                <span>{{ item.units_sold }} units</span>
                <span>{{ item.orders_count }} orders</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .reports-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
      }

      .report-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        padding: 25px;
      }

      .report-card.full-width {
        grid-column: 1 / -1;
      }

      .report-card h3 {
        margin: 0 0 20px 0;
        font-size: 20px;
        color: #333;
      }

      .form-control {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
        margin-bottom: 15px;
      }

      .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr auto;
        gap: 10px;
        margin-bottom: 15px;
      }

      .filters {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
      }

      .filters .form-control {
        max-width: 200px;
        margin-bottom: 0;
      }

      .report-content {
        display: grid;
        gap: 15px;
      }

      .metric {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
      }

      .metric-label {
        font-size: 14px;
        color: #666;
        font-weight: 500;
      }

      .metric-value {
        font-size: 24px;
        font-weight: 700;
        color: #333;
      }

      .metric-value.price {
        color: #667eea;
      }

      .table-container {
        overflow-x: auto;
      }

      table {
        width: 100%;
        border-collapse: collapse;
      }

      thead {
        background: #f8f9fa;
      }

      th {
        padding: 12px;
        text-align: left;
        font-weight: 600;
        color: #333;
        font-size: 14px;
      }

      td {
        padding: 12px;
        border-top: 1px solid #eee;
        color: #666;
      }

      .list-container {
        max-height: 400px;
        overflow-y: auto;
      }

      .list-item {
        padding: 15px;
        border-bottom: 1px solid #eee;
      }

      .list-item:last-child {
        border-bottom: none;
      }

      .list-item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
      }

      .list-item-name {
        font-weight: 600;
        color: #333;
        font-size: 15px;
      }

      .list-item-value {
        font-weight: 700;
        color: #667eea;
        font-size: 16px;
      }

      .list-item-meta {
        display: flex;
        gap: 15px;
        font-size: 13px;
        color: #999;
      }

      .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 14px;
        transition: all 0.3s ease;
      }

      .btn-primary {
        background: #667eea;
        color: white;
      }

      .btn-primary:hover {
        background: #5568d3;
      }
    `,
  ],
})
export class ReportsComponent implements OnInit {
  dailyEarnings: DailyEarnings | null = null;
  monthlyEarnings: MonthlyEarnings | null = null;
  topProducts: TopSellingProduct[] = [];
  salesByCategory: SalesByCategory[] = [];
  salesByBrand: SalesByBrand[] = [];

  selectedDate = new Date().toISOString().split('T')[0];
  selectedYear = new Date().getFullYear();
  selectedMonth = new Date().getMonth() + 1;
  productPeriod = '';
  productLimit = 10;
  categoryPeriod = '';
  brandPeriod = '';

  constructor(private reportService: ReportService) {}

  ngOnInit(): void {
    this.loadDailyEarnings();
    this.loadMonthlyEarnings();
    this.loadTopProducts();
    this.loadSalesByCategory();
    this.loadSalesByBrand();
  }

  loadDailyEarnings(): void {
    this.reportService.getDailyEarnings(this.selectedDate).subscribe({
      next: (response) => {
        this.dailyEarnings = response.daily_earnings;
      },
    });
  }

  loadMonthlyEarnings(): void {
    this.reportService.getMonthlyEarnings(this.selectedYear, this.selectedMonth).subscribe({
      next: (response) => {
        this.monthlyEarnings = response.monthly_earnings;
      },
    });
  }

  loadTopProducts(): void {
    this.reportService
      .getTopSellingProducts(this.productLimit, this.productPeriod || undefined)
      .subscribe({
        next: (response) => {
          this.topProducts = response.top_selling_products;
        },
      });
  }

  loadSalesByCategory(): void {
    this.reportService.getSalesByCategory(this.categoryPeriod || undefined).subscribe({
      next: (response) => {
        this.salesByCategory = response.sales_by_category;
      },
    });
  }

  loadSalesByBrand(): void {
    this.reportService.getSalesByBrand(this.brandPeriod || undefined).subscribe({
      next: (response) => {
        this.salesByBrand = response.sales_by_brand;
      },
    });
  }
}
