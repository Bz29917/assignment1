import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { ReportService } from '../../services/report.service';
import { AuthService } from '../../services/auth.service';
import { Dashboard } from '../../models/report.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="dashboard-container">
      <!-- Simple User View -->
      <div *ngIf="isSimpleUser()" class="simple-user-dashboard">
        <div class="dashboard-header">
          <h1>Welcome to Your Dashboard</h1>
          <p>Browse our products and place orders easily.</p>
        </div>

        <div class="simple-user-content">
          <div class="welcome-card">
            <div class="welcome-icon">👋</div>
            <h2>Hello, {{ currentUserName }}!</h2>
            <p>You have access to browse products and place orders.</p>
          </div>

          <div class="quick-actions">
            <h2>Quick Actions</h2>
            <div class="actions-grid">
              <a routerLink="/products" class="action-card">
                <span class="action-icon">🛍️</span>
                <span class="action-text">Browse Products</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      <!-- Admin/Advanced User View -->
      <div *ngIf="!isSimpleUser()">
        <div class="dashboard-header">
          <h1>Dashboard</h1>
          <p>Welcome back! Here's what's happening with your store today.</p>
        </div>

        <div class="stats-grid" *ngIf="dashboardData">
          <div class="stat-card">
            <div class="stat-icon" style="background: #667eea;">
              <span>📦</span>
            </div>
            <div class="stat-content">
              <h3>Total Orders</h3>
              <p class="stat-value">{{ dashboardData.overall.total_orders }}</p>
              <span class="stat-label">Pending: {{ dashboardData.overall.pending_orders }}</span>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon" style="background: #48bb78;">
              <span>💰</span>
            </div>
            <div class="stat-content">
              <h3>Total Revenue</h3>
              <p class="stat-value">
                \${{ dashboardData.overall.total_revenue | number : '1.2-2' }}
              </p>
              <span class="stat-label"
                >Avg: \${{ dashboardData.overall.average_order_value | number : '1.2-2' }}</span
              >
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon" style="background: #ed8936;">
              <span>📊</span>
            </div>
            <div class="stat-content">
              <h3>Today's Orders</h3>
              <p class="stat-value">{{ dashboardData.today.orders_today }}</p>
              <span class="stat-label"
                >Revenue: \${{ dashboardData.today.revenue_today | number : '1.2-2' }}</span
              >
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon" style="background: #e53e3e;">
              <span>👥</span>
            </div>
            <div class="stat-content">
              <h3>Total Clients</h3>
              <p class="stat-value">{{ dashboardData.clients.total_clients }}</p>
              <span class="stat-label">Active customers</span>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon" style="background: #38b2ac;">
              <span>🛒</span>
            </div>
            <div class="stat-content">
              <h3>Total Products</h3>
              <p class="stat-value">{{ dashboardData.products.total_products }}</p>
              <span class="stat-label">In stock: {{ dashboardData.products.available_stock }}</span>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon" style="background: #9f7aea;">
              <span>📅</span>
            </div>
            <div class="stat-content">
              <h3>This Month</h3>
              <p class="stat-value">{{ dashboardData.this_month.orders_this_month }}</p>
              <span class="stat-label"
                >Revenue: \${{
                  dashboardData.this_month.revenue_this_month | number : '1.2-2'
                }}</span
              >
            </div>
          </div>
        </div>

        <div class="quick-actions">
          <h2>Quick Actions</h2>
          <div class="actions-grid">
            <a routerLink="/products/create" class="action-card">
              <span class="action-icon">➕</span>
              <span class="action-text">Add Product</span>
            </a>
            <a
              routerLink="/orders/create"
              class="action-card"
              *ngIf="hasRole('admin', 'advanced_user')"
            >
              <span class="action-icon">🛒</span>
              <span class="action-text">Create Order</span>
            </a>
            <a
              routerLink="/clients/create"
              class="action-card"
              *ngIf="hasRole('admin', 'advanced_user')"
            >
              <span class="action-icon">👤</span>
              <span class="action-text">Add Client</span>
            </a>
            <a routerLink="/reports" class="action-card" *ngIf="hasRole('admin', 'advanced_user')">
              <span class="action-icon">📈</span>
              <span class="action-text">View Reports</span>
            </a>
          </div>
        </div>

        <div class="loading" *ngIf="loading">Loading dashboard data...</div>
        <div class="error" *ngIf="error">{{ error }}</div>
      </div>
    </div>
  `,
  styles: [
    `
      .dashboard-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .dashboard-header {
        margin-bottom: 30px;
      }

      .dashboard-header h1 {
        font-size: 32px;
        color: #333;
        margin: 0 0 10px 0;
      }

      .dashboard-header p {
        color: #666;
        margin: 0;
        font-size: 16px;
      }

      .simple-user-dashboard {
        max-width: 900px;
        margin: 0 auto;
      }

      .simple-user-content {
        margin-top: 30px;
      }

      .welcome-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 16px;
        padding: 40px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
        margin-bottom: 40px;
      }

      .welcome-icon {
        font-size: 64px;
        margin-bottom: 20px;
      }

      .welcome-card h2 {
        font-size: 28px;
        margin: 0 0 15px 0;
        font-weight: 700;
      }

      .welcome-card p {
        font-size: 16px;
        margin: 0;
        opacity: 0.95;
      }

      .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 40px;
      }

      .stat-card {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        display: flex;
        gap: 15px;
        transition: transform 0.3s ease;
      }

      .stat-card:hover {
        transform: translateY(-5px);
      }

      .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
      }

      .stat-content {
        flex: 1;
      }

      .stat-content h3 {
        font-size: 14px;
        color: #666;
        margin: 0 0 8px 0;
        font-weight: 500;
      }

      .stat-value {
        font-size: 28px;
        font-weight: 700;
        color: #333;
        margin: 0 0 5px 0;
      }

      .stat-label {
        font-size: 12px;
        color: #999;
      }

      .quick-actions {
        margin-top: 40px;
      }

      .quick-actions h2 {
        font-size: 24px;
        color: #333;
        margin: 0 0 20px 0;
      }

      .actions-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
      }

      .action-card {
        background: white;
        border-radius: 12px;
        padding: 25px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
        text-decoration: none;
        transition: all 0.3s ease;
      }

      .action-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
      }

      .action-icon {
        font-size: 36px;
      }

      .action-text {
        font-size: 16px;
        font-weight: 600;
        color: #333;
      }

      .loading {
        text-align: center;
        padding: 40px;
        color: #666;
      }

      .error {
        background: #fee;
        color: #c33;
        padding: 15px;
        border-radius: 8px;
        text-align: center;
      }
    `,
  ],
})
export class DashboardComponent implements OnInit {
  dashboardData: Dashboard | null = null;
  loading = true;
  error = '';
  currentUserName = '';

  constructor(private reportService: ReportService, private authService: AuthService) {}

  ngOnInit(): void {
    const currentUser = this.authService.getCurrentUser();

    if (currentUser) {
      if (currentUser.first_name && currentUser.last_name) {
        this.currentUserName = `${currentUser.first_name} ${currentUser.last_name}`;
      } else if (currentUser.first_name) {
        this.currentUserName = currentUser.first_name;
      } else {
        this.currentUserName = currentUser.username;
      }
    } else {
      this.currentUserName = 'User';
    }

    if (!this.isSimpleUser()) {
      this.loadDashboard();
    } else {
      this.loading = false;
    }
  }

  loadDashboard(): void {
    this.reportService.getDashboard().subscribe({
      next: (response) => {
        this.dashboardData = response.dashboard;
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to load dashboard data';
        this.loading = false;
      },
    });
  }

  hasRole(...roles: string[]): boolean {
    return this.authService.hasRole(...roles);
  }

  isSimpleUser(): boolean {
    return this.authService.hasRole('simple_user');
  }
}
