import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../navbar/navbar.component';
import { UserService } from '../../../services/user.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container">
      <div class="header">
        <h1>Users Management</h1>
      </div>

      <div class="users-table" *ngIf="!loading">
        <table>
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th>Role</th>
              <th>Name</th>
              <th>Status</th>
              <th>Last Login</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let user of users">
              <td>{{ user.username }}</td>
              <td>{{ user.email }}</td>
              <td>
                <span class="role-badge" [ngClass]="'role-' + user.role">
                  {{ user.role }}
                </span>
              </td>
              <td>{{ user.first_name }} {{ user.last_name }}</td>
              <td>
                <span class="status-badge" [class.active]="user.is_active">
                  {{ user.is_active ? 'Active' : 'Inactive' }}
                </span>
              </td>
              <td>{{ user.last_login ? (user.last_login | date : 'short') : 'Never' }}</td>
              <td>
                <a [routerLink]="['/users/edit', user.id]" class="btn btn-sm">Edit</a>
                <button (click)="toggleStatus(user)" class="btn btn-sm btn-warning">
                  {{ user.is_active ? 'Deactivate' : 'Activate' }}
                </button>
                <button (click)="deleteUser(user.id)" class="btn btn-sm btn-danger">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="loading" *ngIf="loading">Loading users...</div>
      <div class="empty" *ngIf="!loading && users.length === 0">No users found.</div>
    </div>
  `,
  styles: [
    `
      .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 30px 20px;
      }

      .header {
        margin-bottom: 30px;
      }

      .header h1 {
        font-size: 32px;
        color: #333;
        margin: 0;
      }

      .users-table {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
      }

      table {
        width: 100%;
        border-collapse: collapse;
      }

      thead {
        background: #f8f9fa;
      }

      th {
        padding: 15px;
        text-align: left;
        font-weight: 600;
        color: #333;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      td {
        padding: 15px;
        border-top: 1px solid #eee;
        color: #666;
      }

      tbody tr:hover {
        background: #f8f9fa;
      }

      .role-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
      }

      .role-admin {
        background: #fee2e2;
        color: #991b1b;
      }

      .role-advanced_user {
        background: #dbeafe;
        color: #1e40af;
      }

      .role-simple_user {
        background: #e0e7ff;
        color: #3730a3;
      }

      .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        background: #fee2e2;
        color: #991b1b;
      }

      .status-badge.active {
        background: #d1fae5;
        color: #065f46;
      }

      .btn {
        padding: 6px 12px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s ease;
        font-size: 13px;
        margin-right: 5px;
      }

      .btn-sm {
        background: #667eea;
        color: white;
      }

      .btn-sm:hover {
        background: #5568d3;
      }

      .btn-warning {
        background: #ed8936;
        color: white;
      }

      .btn-warning:hover {
        background: #dd6b20;
      }

      .btn-danger {
        background: #e53e3e;
        color: white;
      }

      .btn-danger:hover {
        background: #c53030;
      }

      .loading,
      .empty {
        text-align: center;
        padding: 40px;
        color: #666;
      }
    `,
  ],
})
export class UserListComponent implements OnInit {
  users: User[] = [];
  loading = true;

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.loading = true;
    this.userService.getAll().subscribe({
      next: (response) => {
        this.users = response.users;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }

  toggleStatus(user: User): void {
    const action = user.is_active ? 'deactivate' : 'activate';
    if (confirm(`Are you sure you want to ${action} this user?`)) {
      const request = user.is_active
        ? this.userService.deactivate(user.id)
        : this.userService.activate(user.id);

      request.subscribe({
        next: () => {
          this.loadUsers();
        },
      });
    }
  }

  deleteUser(id: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.userService.delete(id).subscribe({
        next: () => {
          this.loadUsers();
        },
      });
    }
  }
}
