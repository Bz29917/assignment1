import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Order, CreateOrderRequest, OrderStatistics } from '../models/order.model';
import { Pagination } from '../models/pagination.model';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private apiUrl = `${environment.apiUrl}/orders`;

  constructor(private http: HttpClient) {}

  getAll(
    page: number = 1,
    limit: number = 20,
    status?: string
  ): Observable<{ orders: Order[]; pagination: Pagination }> {
    let params = new HttpParams().set('page', page.toString()).set('limit', limit.toString());
    if (status) {
      params = params.set('status', status);
    }
    return this.http.get<{ orders: Order[]; pagination: Pagination }>(this.apiUrl, { params });
  }

  getById(id: number): Observable<{ order: Order }> {
    return this.http.get<{ order: Order }>(`${this.apiUrl}/${id}`);
  }

  create(order: CreateOrderRequest): Observable<{ message: string; order: Order }> {
    return this.http.post<{ message: string; order: Order }>(this.apiUrl, order);
  }

  updateStatus(id: number, status: string): Observable<{ message: string; order: Order }> {
    return this.http.patch<{ message: string; order: Order }>(`${this.apiUrl}/${id}/status`, {
      status,
    });
  }

  cancel(id: number): Observable<{ message: string; order: Order }> {
    return this.http.patch<{ message: string; order: Order }>(`${this.apiUrl}/${id}/cancel`, {});
  }

  getStatistics(): Observable<{ statistics: OrderStatistics }> {
    return this.http.get<{ statistics: OrderStatistics }>(`${this.apiUrl}/statistics`);
  }
}
