import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Category, Brand, Size, Color, Gender } from '../models/generic.model';

@Injectable({
  providedIn: 'root',
})
export class GenericService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getCategories(): Observable<{ categories: Category[]; count: number }> {
    return this.http.get<{ categories: Category[]; count: number }>(`${this.apiUrl}/categories`);
  }

  createCategory(data: Partial<Category>): Observable<{ message: string; category: Category }> {
    return this.http.post<{ message: string; category: Category }>(
      `${this.apiUrl}/categories`,
      data
    );
  }

  updateCategory(
    id: number,
    data: Partial<Category>
  ): Observable<{ message: string; category: Category }> {
    return this.http.put<{ message: string; category: Category }>(
      `${this.apiUrl}/categories/${id}`,
      data
    );
  }

  deleteCategory(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/categories/${id}`);
  }

  getBrands(): Observable<{ brands: Brand[]; count: number }> {
    return this.http.get<{ brands: Brand[]; count: number }>(`${this.apiUrl}/brands`);
  }

  createBrand(data: Partial<Brand>): Observable<{ message: string; brand: Brand }> {
    return this.http.post<{ message: string; brand: Brand }>(`${this.apiUrl}/brands`, data);
  }

  updateBrand(id: number, data: Partial<Brand>): Observable<{ message: string; brand: Brand }> {
    return this.http.put<{ message: string; brand: Brand }>(`${this.apiUrl}/brands/${id}`, data);
  }

  deleteBrand(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/brands/${id}`);
  }

  getSizes(): Observable<{ sizes: Size[]; count: number }> {
    return this.http.get<{ sizes: Size[]; count: number }>(`${this.apiUrl}/sizes`);
  }

  createSize(data: Partial<Size>): Observable<{ message: string; size: Size }> {
    return this.http.post<{ message: string; size: Size }>(`${this.apiUrl}/sizes`, data);
  }

  updateSize(id: number, data: Partial<Size>): Observable<{ message: string; size: Size }> {
    return this.http.put<{ message: string; size: Size }>(`${this.apiUrl}/sizes/${id}`, data);
  }

  deleteSize(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/sizes/${id}`);
  }

  getColors(): Observable<{ colors: Color[]; count: number }> {
    return this.http.get<{ colors: Color[]; count: number }>(`${this.apiUrl}/colors`);
  }

  createColor(data: Partial<Color>): Observable<{ message: string; color: Color }> {
    return this.http.post<{ message: string; color: Color }>(`${this.apiUrl}/colors`, data);
  }

  updateColor(id: number, data: Partial<Color>): Observable<{ message: string; color: Color }> {
    return this.http.put<{ message: string; color: Color }>(`${this.apiUrl}/colors/${id}`, data);
  }

  deleteColor(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/colors/${id}`);
  }

  getGenders(): Observable<{ genders: Gender[]; count: number }> {
    return this.http.get<{ genders: Gender[]; count: number }>(`${this.apiUrl}/genders`);
  }

  createGender(data: Partial<Gender>): Observable<{ message: string; gender: Gender }> {
    return this.http.post<{ message: string; gender: Gender }>(`${this.apiUrl}/genders`, data);
  }

  updateGender(id: number, data: Partial<Gender>): Observable<{ message: string; gender: Gender }> {
    return this.http.put<{ message: string; gender: Gender }>(`${this.apiUrl}/genders/${id}`, data);
  }

  deleteGender(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/genders/${id}`);
  }
}
