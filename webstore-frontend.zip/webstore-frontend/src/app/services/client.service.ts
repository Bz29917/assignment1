import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Client } from '../models/client.model';
import { Order } from '../models/order.model';
import { Pagination } from '../models/pagination.model';

@Injectable({
  providedIn: 'root',
})
export class ClientService {
  private apiUrl = `${environment.apiUrl}/clients`;

  constructor(private http: HttpClient) {}

  getAll(
    page: number = 1,
    limit: number = 20
  ): Observable<{ clients: Client[]; pagination: Pagination }> {
    const params = new HttpParams().set('page', page.toString()).set('limit', limit.toString());
    return this.http.get<{ clients: Client[]; pagination: Pagination }>(this.apiUrl, { params });
  }

  getById(id: number): Observable<{ client: Client }> {
    return this.http.get<{ client: Client }>(`${this.apiUrl}/${id}`);
  }

  create(client: Partial<Client>): Observable<{ message: string; client: Client }> {
    return this.http.post<{ message: string; client: Client }>(this.apiUrl, client);
  }

  update(id: number, client: Partial<Client>): Observable<{ message: string; client: Client }> {
    return this.http.put<{ message: string; client: Client }>(`${this.apiUrl}/${id}`, client);
  }

  delete(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/${id}`);
  }

  getOrders(id: number): Observable<{ client_id: number; orders: Order[]; count: number }> {
    return this.http.get<{ client_id: number; orders: Order[]; count: number }>(
      `${this.apiUrl}/${id}/orders`
    );
  }
}
