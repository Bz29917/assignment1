import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Product, ProductQuantity, ProductSearchParams } from '../models/product.model';
import { Pagination } from '../models/pagination.model';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private apiUrl = `${environment.apiUrl}/products`;

  constructor(private http: HttpClient) {}

  getAll(
    page: number = 1,
    limit: number = 20
  ): Observable<{ products: Product[]; pagination: Pagination }> {
    const params = new HttpParams().set('page', page.toString()).set('limit', limit.toString());
    return this.http.get<{ products: Product[]; pagination: Pagination }>(this.apiUrl, { params });
  }

  getById(id: number): Observable<{ product: Product }> {
    return this.http.get<{ product: Product }>(`${this.apiUrl}/${id}`);
  }

  create(product: Partial<Product>): Observable<{ message: string; product: Product }> {
    return this.http.post<{ message: string; product: Product }>(this.apiUrl, product);
  }

  update(id: number, product: Partial<Product>): Observable<{ message: string; product: Product }> {
    return this.http.put<{ message: string; product: Product }>(`${this.apiUrl}/${id}`, product);
  }

  delete(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/${id}`);
  }

  search(
    params: ProductSearchParams
  ): Observable<{ products: Product[]; filters: any; pagination: Pagination }> {
    let httpParams = new HttpParams();
    Object.keys(params).forEach((key) => {
      const value = (params as any)[key];
      if (value !== undefined && value !== null && value !== '') {
        httpParams = httpParams.set(key, value.toString());
      }
    });
    return this.http.get<{ products: Product[]; filters: any; pagination: Pagination }>(
      `${this.apiUrl}/search`,
      { params: httpParams }
    );
  }

  getQuantity(id: number): Observable<ProductQuantity> {
    return this.http.get<ProductQuantity>(`${this.apiUrl}/${id}/quantity`);
  }

  applyDiscount(
    id: number,
    discount_percentage: number
  ): Observable<{ message: string; product: Product }> {
    return this.http.patch<{ message: string; product: Product }>(`${this.apiUrl}/${id}/discount`, {
      discount_percentage,
    });
  }

  updateStock(
    id: number,
    quantity: number,
    operation: 'set' | 'add' | 'subtract' = 'set'
  ): Observable<{ message: string; product: Product }> {
    return this.http.patch<{ message: string; product: Product }>(`${this.apiUrl}/${id}/stock`, {
      quantity,
      operation,
    });
  }
}
