import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  Dashboard,
  DailyEarnings,
  MonthlyEarnings,
  DateRangeEarnings,
  TopSellingProduct,
  ProductPerformance,
  SalesByCategory,
  SalesByBrand,
} from '../models/report.model';

@Injectable({
  providedIn: 'root',
})
export class ReportService {
  private apiUrl = `${environment.apiUrl}/reports`;

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<{ dashboard: Dashboard }> {
    return this.http.get<{ dashboard: Dashboard }>(`${this.apiUrl}/dashboard`);
  }

  getDailyEarnings(date?: string): Observable<{ daily_earnings: DailyEarnings }> {
    let params = new HttpParams();
    if (date) {
      params = params.set('date', date);
    }
    return this.http.get<{ daily_earnings: DailyEarnings }>(`${this.apiUrl}/earnings/daily`, {
      params,
    });
  }

  getMonthlyEarnings(
    year?: number,
    month?: number
  ): Observable<{ monthly_earnings: MonthlyEarnings }> {
    let params = new HttpParams();
    if (year) params = params.set('year', year.toString());
    if (month) params = params.set('month', month.toString());
    return this.http.get<{ monthly_earnings: MonthlyEarnings }>(`${this.apiUrl}/earnings/monthly`, {
      params,
    });
  }

  getEarningsByDateRange(start_date: string, end_date: string): Observable<DateRangeEarnings> {
    const params = new HttpParams().set('start_date', start_date).set('end_date', end_date);
    return this.http.get<DateRangeEarnings>(`${this.apiUrl}/earnings/range`, { params });
  }

  getTopSellingProducts(
    limit: number = 10,
    period?: string
  ): Observable<{ period: string; top_selling_products: TopSellingProduct[] }> {
    let params = new HttpParams().set('limit', limit.toString());
    if (period) params = params.set('period', period);
    return this.http.get<{ period: string; top_selling_products: TopSellingProduct[] }>(
      `${this.apiUrl}/products/top-selling`,
      { params }
    );
  }

  getProductPerformance(product_id: number): Observable<ProductPerformance> {
    return this.http.get<ProductPerformance>(`${this.apiUrl}/products/${product_id}/performance`);
  }

  getSalesByCategory(
    period?: string
  ): Observable<{ period: string; sales_by_category: SalesByCategory[] }> {
    let params = new HttpParams();
    if (period) params = params.set('period', period);
    return this.http.get<{ period: string; sales_by_category: SalesByCategory[] }>(
      `${this.apiUrl}/sales/by-category`,
      { params }
    );
  }

  getSalesByBrand(period?: string): Observable<{ period: string; sales_by_brand: SalesByBrand[] }> {
    let params = new HttpParams();
    if (period) params = params.set('period', period);
    return this.http.get<{ period: string; sales_by_brand: SalesByBrand[] }>(
      `${this.apiUrl}/sales/by-brand`,
      { params }
    );
  }
}
