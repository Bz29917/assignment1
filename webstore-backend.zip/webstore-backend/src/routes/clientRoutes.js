const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const clientController = require('../controllers/clientController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { validate } = require('../middleware/validation');

const createClientValidation = [
  body('first_name').trim().notEmpty(),
  body('last_name').trim().notEmpty(),
  body('email').isEmail(),
  body('phone').optional().trim(),
  body('address').optional().trim(),
  body('city').optional().trim(),
  body('country').optional().trim(),
  body('postal_code').optional().trim(),
];

const updateClientValidation = [
  body('first_name').optional().trim().notEmpty(),
  body('last_name').optional().trim().notEmpty(),
  body('email').optional().isEmail(),
];

router.get('/', authenticateToken, authorizeRole('admin', 'advanced_user'), clientController.getAll);
router.get('/:id/orders', authenticateToken, authorizeRole('admin', 'advanced_user'), clientController.getOrders);
router.get('/:id', authenticateToken, authorizeRole('admin', 'advanced_user'), clientController.getById);
router.post('/', authenticateToken, authorizeRole('admin', 'advanced_user'), createClientValidation, validate, clientController.create);
router.put('/:id', authenticateToken, authorizeRole('admin', 'advanced_user'), updateClientValidation, validate, clientController.update);
router.delete('/:id', authenticateToken, authorizeRole('admin'), clientController.delete);

module.exports = router;
