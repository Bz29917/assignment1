const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const userController = require('../controllers/userController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { validate } = require('../middleware/validation');

const updateUserValidation = [
  body('username').optional().trim().isLength({ min: 3 }),
  body('email').optional().isEmail(),
  body('role').optional().isIn(['admin', 'advanced_user', 'simple_user'])
];

const updatePasswordValidation = [
  body('newPassword').isLength({ min: 6 })
];

router.get('/', authenticateToken, authorizeRole('admin'), userController.getAll);
router.get('/role/:role', authenticateToken, authorizeRole('admin'), userController.getByRole);
router.get('/:id', authenticateToken, userController.getById);
router.put('/:id', authenticateToken, updateUserValidation, validate, userController.update);
router.delete('/:id', authenticateToken, authorizeRole('admin'), userController.delete);
router.patch('/:id/deactivate', authenticateToken, authorizeRole('admin'), userController.deactivate);
router.patch('/:id/activate', authenticateToken, authorizeRole('admin'), userController.activate);
router.patch('/:id/password', authenticateToken, updatePasswordValidation, validate, userController.updatePassword);

module.exports = router;
