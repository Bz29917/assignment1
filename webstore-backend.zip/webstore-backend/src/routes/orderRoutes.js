const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const orderController = require('../controllers/orderController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { validate } = require('../middleware/validation');

const createOrderValidation = [
  body('client_id').isInt({ min: 1 }),
  body('items').isArray({ min: 1 }),
  body('items.*.product_id').isInt({ min: 1 }),
  body('items.*.quantity').isInt({ min: 1 }),
  body('notes').optional().trim()
];

const updateStatusValidation = [
  body('status').isIn(['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'])
];

router.get('/', authenticateToken, authorizeRole('admin', 'advanced_user'), orderController.getAll);
router.get('/statistics', authenticateToken, authorizeRole('admin', 'advanced_user'), orderController.getStatistics);
router.get('/:id', authenticateToken, authorizeRole('admin', 'advanced_user'), orderController.getById);
router.post('/', authenticateToken, authorizeRole('admin', 'advanced_user'), createOrderValidation, validate, orderController.create);
router.patch('/:id/status', authenticateToken, authorizeRole('admin', 'advanced_user'), updateStatusValidation, validate, orderController.updateStatus);
router.patch('/:id/cancel', authenticateToken, authorizeRole('admin', 'advanced_user'), orderController.cancel);

module.exports = router;
