const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const productController = require('../controllers/productController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { validate } = require('../middleware/validation');

const createProductValidation = [
  body('name').trim().notEmpty(),
  body('description').optional().trim(),
  body('price').isFloat({ min: 0 }),
  body('discount_percentage').optional().isFloat({ min: 0, max: 100 }),
  body('initial_quantity').isInt({ min: 0 }),
  body('gender_id').optional().isInt(),
  body('category_id').optional().isInt(),
  body('brand_id').optional().isInt(),
  body('size_id').optional().isInt(),
  body('color_id').optional().isInt()
];

const updateProductValidation = [
  body('name').optional().trim().notEmpty(),
  body('price').optional().isFloat({ min: 0 }),
  body('discount_percentage').optional().isFloat({ min: 0, max: 100 }),
  body('initial_quantity').optional().isInt({ min: 0 })
];

const applyDiscountValidation = [body('discount_percentage').isFloat({ min: 0, max: 100 })];

const updateStockValidation = [
  body('quantity').isInt({ min: 0 }),
  body('operation').optional().isIn(['set', 'add', 'subtract'])
];

router.get('/', productController.getAll);
router.get('/search', productController.search);
router.get('/:id', productController.getById);
router.get('/:id/quantity', productController.getQuantity);
router.post('/', authenticateToken, authorizeRole('admin', 'advanced_user', 'simple_user'), createProductValidation, validate, productController.create);
router.put('/:id', authenticateToken, authorizeRole('admin', 'advanced_user', 'simple_user'), updateProductValidation, validate, productController.update);
router.delete('/:id', authenticateToken, authorizeRole('admin'), productController.delete);
router.patch('/:id/discount', authenticateToken, authorizeRole('admin', 'advanced_user'), applyDiscountValidation, validate, productController.applyDiscount);
router.patch('/:id/stock', authenticateToken, authorizeRole('admin', 'advanced_user'), updateStockValidation, validate, productController.updateStock);

module.exports = router;
