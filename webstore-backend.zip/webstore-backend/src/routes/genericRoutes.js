const express = require('express');
const { body } = require('express-validator');
const { categoryController, brandController, sizeController, colorController, genderController } = require('../controllers/genericController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { validate } = require('../middleware/validation');

const nameValidation = [body('name').trim().notEmpty()];
const categoryBrandValidation = [body('name').trim().notEmpty(), body('description').optional().trim()];
const colorValidation = [
  body('name').trim().notEmpty(),
  body('hex_code').optional().matches(/^#[0-9A-F]{6}$/i)
];
const sizeValidation = [
  body('name').trim().notEmpty(),
  body('sort_order').optional().isInt({ min: 0 })
];

function createRoutes(controller, rules = nameValidation) {
  const router = express.Router();
  router.get('/', controller.getAll.bind(controller));
  router.get('/:id', controller.getById.bind(controller));
  router.post('/', authenticateToken, authorizeRole('admin', 'advanced_user'), rules, validate, controller.create.bind(controller));
  router.put('/:id', authenticateToken, authorizeRole('admin', 'advanced_user'), rules, validate, controller.update.bind(controller));
  router.delete('/:id', authenticateToken, authorizeRole('admin'), controller.delete.bind(controller));
  return router;
}

module.exports = {
  categoryRoutes: createRoutes(categoryController, categoryBrandValidation),
  brandRoutes: createRoutes(brandController, categoryBrandValidation),
  sizeRoutes: createRoutes(sizeController, sizeValidation),
  colorRoutes: createRoutes(colorController, colorValidation),
  genderRoutes: createRoutes(genderController, nameValidation)
};
