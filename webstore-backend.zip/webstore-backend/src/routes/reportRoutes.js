const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

router.get('/dashboard', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getDashboard);
router.get('/earnings/daily', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getDailyEarnings);
router.get('/earnings/monthly', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getMonthlyEarnings);
router.get('/earnings/range', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getEarningsByDateRange);
router.get('/products/top-selling', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getTopSellingProducts);
router.get('/products/:product_id/performance', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getProductPerformance);
router.get('/sales/by-category', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getSalesByCategory);
router.get('/sales/by-brand', authenticateToken, authorizeRole('admin', 'advanced_user'), reportController.getSalesByBrand);

module.exports = router;
