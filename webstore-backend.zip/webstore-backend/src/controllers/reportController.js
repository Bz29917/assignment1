const { pool } = require("../config/database");

class ReportController {
  async getDailyEarnings(req, res) {
    const { date } = req.query;

    try {
      let query, params;

      if (date) {
        query = `
          SELECT 
            DATE(created_at) as date,
            COUNT(*) as total_orders,
            SUM(total_amount) as total_earnings,
            AVG(total_amount) as average_order_value
          FROM orders
          WHERE DATE(created_at) = $1 AND status != 'cancelled'
          GROUP BY DATE(created_at)
        `;
        params = [date];
      } else {
        query = `
          SELECT 
            DATE(created_at) as date,
            COUNT(*) as total_orders,
            SUM(total_amount) as total_earnings,
            AVG(total_amount) as average_order_value
          FROM orders
          WHERE DATE(created_at) = CURRENT_DATE AND status != 'cancelled'
          GROUP BY DATE(created_at)
        `;
        params = [];
      }

      const result = await pool.query(query, params);

      if (result.rows.length === 0) {
        return res.json({
          date: date || new Date().toISOString().split("T")[0],
          total_orders: 0,
          total_earnings: 0,
          average_order_value: 0,
        });
      }

      res.json({ daily_earnings: result.rows[0] });
    } catch (error) {
      console.error("Get daily earnings error:", error);
      res.status(500).json({
        error: "Failed to get daily earnings",
        details: error.message,
      });
    }
  }

  async getMonthlyEarnings(req, res) {
    const { year, month } = req.query;

    try {
      let query, params;

      if (year && month) {
        query = `
          SELECT 
            EXTRACT(YEAR FROM created_at) as year,
            EXTRACT(MONTH FROM created_at) as month,
            COUNT(*) as total_orders,
            SUM(total_amount) as total_earnings,
            AVG(total_amount) as average_order_value
          FROM orders
          WHERE EXTRACT(YEAR FROM created_at) = $1 
            AND EXTRACT(MONTH FROM created_at) = $2 
            AND status != 'cancelled'
          GROUP BY EXTRACT(YEAR FROM created_at), EXTRACT(MONTH FROM created_at)
        `;
        params = [year, month];
      } else {
        query = `
          SELECT 
            EXTRACT(YEAR FROM created_at) as year,
            EXTRACT(MONTH FROM created_at) as month,
            COUNT(*) as total_orders,
            SUM(total_amount) as total_earnings,
            AVG(total_amount) as average_order_value
          FROM orders
          WHERE EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM CURRENT_DATE)
            AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM CURRENT_DATE)
            AND status != 'cancelled'
          GROUP BY EXTRACT(YEAR FROM created_at), EXTRACT(MONTH FROM created_at)
        `;
        params = [];
      }

      const result = await pool.query(query, params);

      if (result.rows.length === 0) {
        return res.json({
          year: year || new Date().getFullYear(),
          month: month || new Date().getMonth() + 1,
          total_orders: 0,
          total_earnings: 0,
          average_order_value: 0,
        });
      }

      res.json({ monthly_earnings: result.rows[0] });
    } catch (error) {
      console.error("Get monthly earnings error:", error);
      res.status(500).json({
        error: "Failed to get monthly earnings",
        details: error.message,
      });
    }
  }

  async getEarningsByDateRange(req, res) {
    const { start_date, end_date } = req.query;

    if (!start_date || !end_date) {
      return res
        .status(400)
        .json({ error: "start_date and end_date are required" });
    }

    try {
      const result = await pool.query(
        `SELECT 
          DATE(created_at) as date,
          COUNT(*) as orders_count,
          SUM(total_amount) as earnings
        FROM orders
        WHERE DATE(created_at) BETWEEN $1 AND $2 AND status != 'cancelled'
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) ASC`,
        [start_date, end_date]
      );

      const totalResult = await pool.query(
        `SELECT 
          COUNT(*) as total_orders,
          SUM(total_amount) as total_earnings,
          AVG(total_amount) as average_order_value
        FROM orders
        WHERE DATE(created_at) BETWEEN $1 AND $2 AND status != 'cancelled'`,
        [start_date, end_date]
      );

      res.json({
        date_range: { start_date, end_date },
        summary: totalResult.rows[0],
        daily_breakdown: result.rows,
      });
    } catch (error) {
      console.error("Get earnings by date range error:", error);
      res.status(500).json({
        error: "Failed to get earnings by date range",
        details: error.message,
      });
    }
  }

  async getTopSellingProducts(req, res) {
    const { limit = 10, period } = req.query;

    try {
      let dateFilter = "";

      switch (period) {
        case "today":
          dateFilter = "AND DATE(o.created_at) = CURRENT_DATE";
          break;
        case "week":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '7 days'";
          break;
        case "month":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '1 month'";
          break;
        case "year":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '1 year'";
          break;
        default:
          dateFilter = "";
      }

      const query = `
        SELECT 
          p.id,
          p.name,
          p.price,
          p.discounted_price,
          c.name as category_name,
          b.name as brand_name,
          SUM(oi.quantity) as total_sold,
          SUM(oi.total_price) as total_revenue,
          COUNT(DISTINCT oi.order_id) as times_ordered
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN orders o ON oi.order_id = o.id
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        WHERE o.status != 'cancelled' ${dateFilter}
        GROUP BY p.id, p.name, p.price, p.discounted_price, c.name, b.name
        ORDER BY total_sold DESC
        LIMIT $1
      `;

      const result = await pool.query(query, [limit]);

      res.json({
        period: period || "all",
        top_selling_products: result.rows,
      });
    } catch (error) {
      console.error("Get top-selling products error:", error);
      res.status(500).json({
        error: "Failed to get top-selling products",
        details: error.message,
      });
    }
  }

  async getProductPerformance(req, res) {
    const { product_id } = req.params;

    try {
      const salesResult = await pool.query(
        `SELECT 
          p.id,
          p.name,
          p.price,
          p.discounted_price,
          p.initial_quantity,
          pq.sold_quantity,
          pq.current_quantity,
          COUNT(DISTINCT oi.order_id) as times_ordered,
          SUM(oi.quantity) as total_units_sold,
          SUM(oi.total_price) as total_revenue,
          AVG(oi.unit_price) as average_selling_price
        FROM products p
        LEFT JOIN product_quantities pq ON p.id = pq.id
        LEFT JOIN order_items oi ON p.id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.id AND o.status != 'cancelled'
        WHERE p.id = $1
        GROUP BY p.id, p.name, p.price, p.discounted_price, p.initial_quantity, 
                 pq.sold_quantity, pq.current_quantity`,
        [product_id]
      );

      if (salesResult.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      const monthlyResult = await pool.query(
        `SELECT 
          EXTRACT(YEAR FROM o.created_at) as year,
          EXTRACT(MONTH FROM o.created_at) as month,
          SUM(oi.quantity) as units_sold,
          SUM(oi.total_price) as revenue
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.product_id = $1 AND o.status != 'cancelled'
        GROUP BY EXTRACT(YEAR FROM o.created_at), EXTRACT(MONTH FROM o.created_at)
        ORDER BY year DESC, month DESC
        LIMIT 12`,
        [product_id]
      );

      res.json({
        product_performance: salesResult.rows[0],
        monthly_sales: monthlyResult.rows,
      });
    } catch (error) {
      console.error("Get product performance error:", error);
      res.status(500).json({
        error: "Failed to get product performance",
        details: error.message,
      });
    }
  }

  async getSalesByCategory(req, res) {
    const { period } = req.query;

    try {
      let dateFilter = "";

      switch (period) {
        case "today":
          dateFilter = "AND DATE(o.created_at) = CURRENT_DATE";
          break;
        case "week":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '7 days'";
          break;
        case "month":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '1 month'";
          break;
        case "year":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '1 year'";
          break;
        default:
          dateFilter = "";
      }

      const result = await pool.query(
        `SELECT 
          c.id,
          c.name as category_name,
          COUNT(DISTINCT oi.order_id) as orders_count,
          SUM(oi.quantity) as units_sold,
          SUM(oi.total_price) as total_revenue
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN categories c ON p.category_id = c.id
        JOIN orders o ON oi.order_id = o.id
        WHERE o.status != 'cancelled' ${dateFilter}
        GROUP BY c.id, c.name
        ORDER BY total_revenue DESC`
      );

      res.json({
        period: period || "all",
        sales_by_category: result.rows,
      });
    } catch (error) {
      console.error("Get sales by category error:", error);
      res.status(500).json({
        error: "Failed to get sales by category",
        details: error.message,
      });
    }
  }

  async getSalesByBrand(req, res) {
    const { period } = req.query;

    try {
      let dateFilter = "";

      switch (period) {
        case "today":
          dateFilter = "AND DATE(o.created_at) = CURRENT_DATE";
          break;
        case "week":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '7 days'";
          break;
        case "month":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '1 month'";
          break;
        case "year":
          dateFilter = "AND o.created_at >= CURRENT_DATE - INTERVAL '1 year'";
          break;
        default:
          dateFilter = "";
      }

      const result = await pool.query(
        `SELECT 
          b.id,
          b.name as brand_name,
          COUNT(DISTINCT oi.order_id) as orders_count,
          SUM(oi.quantity) as units_sold,
          SUM(oi.total_price) as total_revenue
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN brands b ON p.brand_id = b.id
        JOIN orders o ON oi.order_id = o.id
        WHERE o.status != 'cancelled' ${dateFilter}
        GROUP BY b.id, b.name
        ORDER BY total_revenue DESC`
      );

      res.json({
        period: period || "all",
        sales_by_brand: result.rows,
      });
    } catch (error) {
      console.error("Get sales by brand error:", error);
      res.status(500).json({
        error: "Failed to get sales by brand",
        details: error.message,
      });
    }
  }

  async getDashboard(req, res) {
    try {
      const overallStats = await pool.query(`
        SELECT 
          COUNT(*) as total_orders,
          SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END) as total_revenue,
          AVG(CASE WHEN status != 'cancelled' THEN total_amount ELSE NULL END) as average_order_value,
          COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
          COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_orders
        FROM orders
      `);

      const todayStats = await pool.query(`
        SELECT 
          COUNT(*) as orders_today,
          SUM(total_amount) as revenue_today
        FROM orders
        WHERE DATE(created_at) = CURRENT_DATE AND status != 'cancelled'
      `);

      const monthStats = await pool.query(`
        SELECT 
          COUNT(*) as orders_this_month,
          SUM(total_amount) as revenue_this_month
        FROM orders
        WHERE EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM CURRENT_DATE)
          AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM CURRENT_DATE)
          AND status != 'cancelled'
      `);

      const productStats = await pool.query(`
        SELECT 
          COUNT(*) as total_products,
          SUM(pq.initial_quantity) as total_stock,
          SUM(pq.current_quantity) as available_stock,
          COUNT(CASE WHEN pq.current_quantity = 0 THEN 1 END) as out_of_stock_count
        FROM products p
        LEFT JOIN product_quantities pq ON p.id = pq.id
        WHERE p.is_active = true
      `);

      const clientStats = await pool.query(`
        SELECT COUNT(*) as total_clients
        FROM clients
      `);

      res.json({
        dashboard: {
          overall: overallStats.rows[0],
          today: todayStats.rows[0],
          this_month: monthStats.rows[0],
          products: productStats.rows[0],
          clients: clientStats.rows[0],
        },
      });
    } catch (error) {
      console.error("Get dashboard error:", error);
      res.status(500).json({
        error: "Failed to get dashboard data",
        details: error.message,
      });
    }
  }
}

module.exports = new ReportController();
