const { pool } = require("../config/database");

class GenericController {
  constructor(tableName, entityName) {
    this.tableName = tableName;
    this.entityName = entityName;
  }

  async getAll(req, res) {
    try {
      const result = await pool.query(
        `SELECT * FROM ${this.tableName} ORDER BY id ASC`
      );

      const pluralName = this.tableName;

      res.json({
        [pluralName]: result.rows,
        count: result.rows.length,
      });
    } catch (error) {
      console.error(`Get all ${this.entityName}s error:`, error);
      res.status(500).json({
        error: `Failed to fetch ${this.entityName}s`,
        details: error.message,
      });
    }
  }

  async getById(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `SELECT * FROM ${this.tableName} WHERE id = $1`,
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: `${this.entityName} not found` });
      }

      res.json({ [this.entityName]: result.rows[0] });
    } catch (error) {
      console.error(`Get ${this.entityName} error:`, error);
      res.status(500).json({
        error: `Failed to fetch ${this.entityName}`,
        details: error.message,
      });
    }
  }

  async create(req, res) {
    const { name, description, hex_code, sort_order } = req.body;

    try {
      let query;
      let params;

      if (this.tableName === "colors" && hex_code) {
        query = `INSERT INTO ${this.tableName} (name, hex_code) VALUES ($1, $2) RETURNING *`;
        params = [name, hex_code];
      } else if (this.tableName === "sizes" && sort_order) {
        query = `INSERT INTO ${this.tableName} (name, sort_order) VALUES ($1, $2) RETURNING *`;
        params = [name, sort_order];
      } else if (description) {
        query = `INSERT INTO ${this.tableName} (name, description) VALUES ($1, $2) RETURNING *`;
        params = [name, description];
      } else {
        query = `INSERT INTO ${this.tableName} (name) VALUES ($1) RETURNING *`;
        params = [name];
      }

      const result = await pool.query(query, params);

      res.status(201).json({
        message: `${this.entityName} created successfully`,
        [this.entityName]: result.rows[0],
      });
    } catch (error) {
      console.error(`Create ${this.entityName} error:`, error);

      if (error.code === "23505") {
        return res
          .status(400)
          .json({ error: `${this.entityName} with this name already exists` });
      }

      res.status(500).json({
        error: `Failed to create ${this.entityName}`,
        details: error.message,
      });
    }
  }

  async update(req, res) {
    const { id } = req.params;
    const { name, description, hex_code, sort_order } = req.body;

    try {
      let query;
      let params;

      if (this.tableName === "colors") {
        query = `UPDATE ${this.tableName} 
                 SET name = COALESCE($1, name), 
                     hex_code = COALESCE($2, hex_code),
                     updated_at = NOW()
                 WHERE id = $3 RETURNING *`;
        params = [name, hex_code, id];
      } else if (this.tableName === "sizes") {
        query = `UPDATE ${this.tableName} 
                 SET name = COALESCE($1, name), 
                     sort_order = COALESCE($2, sort_order)
                 WHERE id = $3 RETURNING *`;
        params = [name, sort_order, id];
      } else if (
        this.tableName === "categories" ||
        this.tableName === "brands"
      ) {
        query = `UPDATE ${this.tableName} 
                 SET name = COALESCE($1, name), 
                     description = COALESCE($2, description),
                     updated_at = NOW()
                 WHERE id = $3 RETURNING *`;
        params = [name, description, id];
      } else {
        query = `UPDATE ${this.tableName} 
                 SET name = COALESCE($1, name)
                 WHERE id = $2 RETURNING *`;
        params = [name, id];
      }

      const result = await pool.query(query, params);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: `${this.entityName} not found` });
      }

      res.json({
        message: `${this.entityName} updated successfully`,
        [this.entityName]: result.rows[0],
      });
    } catch (error) {
      console.error(`Update ${this.entityName} error:`, error);
      res.status(500).json({
        error: `Failed to update ${this.entityName}`,
        details: error.message,
      });
    }
  }

  async delete(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `DELETE FROM ${this.tableName} WHERE id = $1 RETURNING *`,
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: `${this.entityName} not found` });
      }

      res.json({ message: `${this.entityName} deleted successfully` });
    } catch (error) {
      console.error(`Delete ${this.entityName} error:`, error);

      if (error.code === "23503") {
        return res.status(400).json({
          error: `Cannot delete ${this.entityName} because it is referenced by other records`,
        });
      }

      res.status(500).json({
        error: `Failed to delete ${this.entityName}`,
        details: error.message,
      });
    }
  }
}

const categoryController = new GenericController("categories", "category");
const brandController = new GenericController("brands", "brand");
const sizeController = new GenericController("sizes", "size");
const colorController = new GenericController("colors", "color");
const genderController = new GenericController("genders", "gender");

module.exports = {
  categoryController,
  brandController,
  sizeController,
  colorController,
  genderController,
};
