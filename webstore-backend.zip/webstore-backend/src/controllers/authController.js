const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { pool } = require("../config/database");

class AuthController {
  async register(req, res) {
    const { username, email, password, role, first_name, last_name } = req.body;

    try {
      const userExists = await pool.query(
        "SELECT * FROM users WHERE email = $1 OR username = $2",
        [email, username]
      );

      if (userExists.rows.length > 0) {
        return res
          .status(400)
          .json({ error: "User with this email or username already exists." });
      }

      const saltRounds = 10;
      const password_hash = await bcrypt.hash(password, saltRounds);

      const newUser = await pool.query(
        `INSERT INTO users (username, email, password_hash, role, first_name, last_name) 
         VALUES ($1, $2, $3, $4, $5, $6) 
         RETURNING id, username, email, role, first_name, last_name, created_at`,
        [
          username,
          email,
          password_hash,
          role || "simple_user",
          first_name,
          last_name,
        ]
      );

      res.status(201).json({
        message: "User registered successfully",
        user: newUser.rows[0],
      });
    } catch (error) {
      console.error("Registration error:", error);
      res
        .status(500)
        .json({ error: "Failed to register user", details: error.message });
    }
  }

  async login(req, res) {
    const { email, password } = req.body;

    try {
      const result = await pool.query(
        "SELECT * FROM users WHERE email = $1 AND is_active = true",
        [email]
      );

      if (result.rows.length === 0) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const user = result.rows[0];

      const validPassword = await bcrypt.compare(password, user.password_hash);

      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      await pool.query("UPDATE users SET last_login = NOW() WHERE id = $1", [
        user.id,
      ]);

      const token = jwt.sign(
        {
          id: user.id,
          email: user.email,
          username: user.username,
          role: user.role,
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN }
      );

      res.json({
        message: "Login successful",
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          first_name: user.first_name,
          last_name: user.last_name,
        },
      });
    } catch (error) {
      console.error("Login error:", error);
      res
        .status(500)
        .json({ error: "Failed to login", details: error.message });
    }
  }

  async getProfile(req, res) {
    try {
      const result = await pool.query(
        `SELECT id, username, email, role, first_name, last_name, is_active, created_at, last_login 
         FROM users WHERE id = $1`,
        [req.user.id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ user: result.rows[0] });
    } catch (error) {
      console.error("Get profile error:", error);
      res
        .status(500)
        .json({ error: "Failed to get profile", details: error.message });
    }
  }

  async changePassword(req, res) {
    const { oldPassword, newPassword } = req.body;

    try {
      const result = await pool.query(
        "SELECT password_hash FROM users WHERE id = $1",
        [req.user.id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      const validPassword = await bcrypt.compare(
        oldPassword,
        result.rows[0].password_hash
      );

      if (!validPassword) {
        return res.status(401).json({ error: "Current password is incorrect" });
      }

      const saltRounds = 10;
      const newPasswordHash = await bcrypt.hash(newPassword, saltRounds);

      await pool.query(
        "UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2",
        [newPasswordHash, req.user.id]
      );

      res.json({ message: "Password changed successfully" });
    } catch (error) {
      console.error("Change password error:", error);
      res
        .status(500)
        .json({ error: "Failed to change password", details: error.message });
    }
  }
}

module.exports = new AuthController();
