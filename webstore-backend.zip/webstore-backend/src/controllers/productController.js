const { pool } = require("../config/database");

class ProductController {
  async getAll(req, res) {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    try {
      const result = await pool.query(
        `SELECT p.*, 
                g.name as gender_name,
                c.name as category_name,
                b.name as brand_name,
                s.name as size_name,
                co.name as color_name,
                pq.sold_quantity,
                pq.current_quantity
         FROM products p
         LEFT JOIN genders g ON p.gender_id = g.id
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN brands b ON p.brand_id = b.id
         LEFT JOIN sizes s ON p.size_id = s.id
         LEFT JOIN colors co ON p.color_id = co.id
         LEFT JOIN product_quantities pq ON p.id = pq.id
         WHERE p.is_active = true
         ORDER BY p.created_at DESC
         LIMIT $1 OFFSET $2`,
        [limit, offset]
      );

      const countResult = await pool.query(
        "SELECT COUNT(*) FROM products WHERE is_active = true"
      );
      const total = parseInt(countResult.rows[0].count);

      res.json({
        products: result.rows,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      console.error("Get products error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch products", details: error.message });
    }
  }

  async getById(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `SELECT p.*, 
                g.name as gender_name,
                c.name as category_name,
                b.name as brand_name,
                s.name as size_name,
                co.name as color_name,
                pq.sold_quantity,
                pq.current_quantity
         FROM products p
         LEFT JOIN genders g ON p.gender_id = g.id
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN brands b ON p.brand_id = b.id
         LEFT JOIN sizes s ON p.size_id = s.id
         LEFT JOIN colors co ON p.color_id = co.id
         LEFT JOIN product_quantities pq ON p.id = pq.id
         WHERE p.id = $1`,
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      res.json({ product: result.rows[0] });
    } catch (error) {
      console.error("Get product error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch product", details: error.message });
    }
  }

  async create(req, res) {
    const {
      name,
      description,
      price,
      discount_percentage = 0,
      initial_quantity,
      gender_id,
      category_id,
      brand_id,
      size_id,
      color_id,
    } = req.body;

    try {
      const result = await pool.query(
        `INSERT INTO products (name, description, price, discount_percentage, initial_quantity, 
                              gender_id, category_id, brand_id, size_id, color_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         RETURNING *`,
        [
          name,
          description,
          price,
          discount_percentage,
          initial_quantity,
          gender_id,
          category_id,
          brand_id,
          size_id,
          color_id,
        ]
      );

      res.status(201).json({
        message: "Product created successfully",
        product: result.rows[0],
      });
    } catch (error) {
      console.error("Create product error:", error);
      res
        .status(500)
        .json({ error: "Failed to create product", details: error.message });
    }
  }

  async update(req, res) {
    const { id } = req.params;
    const {
      name,
      description,
      price,
      discount_percentage,
      initial_quantity,
      gender_id,
      category_id,
      brand_id,
      size_id,
      color_id,
      is_active,
    } = req.body;

    try {
      const checkProduct = await pool.query(
        "SELECT * FROM products WHERE id = $1",
        [id]
      );

      if (checkProduct.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      const result = await pool.query(
        `UPDATE products 
         SET name = COALESCE($1, name),
             description = COALESCE($2, description),
             price = COALESCE($3, price),
             discount_percentage = COALESCE($4, discount_percentage),
             initial_quantity = COALESCE($5, initial_quantity),
             gender_id = COALESCE($6, gender_id),
             category_id = COALESCE($7, category_id),
             brand_id = COALESCE($8, brand_id),
             size_id = COALESCE($9, size_id),
             color_id = COALESCE($10, color_id),
             is_active = COALESCE($11, is_active),
             updated_at = NOW()
         WHERE id = $12
         RETURNING *`,
        [
          name,
          description,
          price,
          discount_percentage,
          initial_quantity,
          gender_id,
          category_id,
          brand_id,
          size_id,
          color_id,
          is_active,
          id,
        ]
      );

      res.json({
        message: "Product updated successfully",
        product: result.rows[0],
      });
    } catch (error) {
      console.error("Update product error:", error);
      res
        .status(500)
        .json({ error: "Failed to update product", details: error.message });
    }
  }

  async delete(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        "UPDATE products SET is_active = false WHERE id = $1 RETURNING *",
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Delete product error:", error);
      res
        .status(500)
        .json({ error: "Failed to delete product", details: error.message });
    }
  }

  async applyDiscount(req, res) {
    const { id } = req.params;
    const { discount_percentage } = req.body;

    try {
      const currentProduct = await pool.query(
        "SELECT * FROM products WHERE id = $1",
        [id]
      );

      if (currentProduct.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      const oldProduct = currentProduct.rows[0];

      const result = await pool.query(
        "UPDATE products SET discount_percentage = $1, updated_at = NOW() WHERE id = $2 RETURNING *",
        [discount_percentage, id]
      );

      await pool.query(
        `INSERT INTO discount_history (product_id, old_price, new_price, old_discount, new_discount, changed_by)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          id,
          oldProduct.price,
          oldProduct.price,
          oldProduct.discount_percentage,
          discount_percentage,
          req.user.id,
        ]
      );

      res.json({
        message: "Discount applied successfully",
        product: result.rows[0],
      });
    } catch (error) {
      console.error("Apply discount error:", error);
      res
        .status(500)
        .json({ error: "Failed to apply discount", details: error.message });
    }
  }

  async updateStock(req, res) {
    const { id } = req.params;
    const { quantity, operation = "set" } = req.body;

    try {
      let query;
      let params;

      if (operation === "set") {
        query =
          "UPDATE products SET initial_quantity = $1, updated_at = NOW() WHERE id = $2 RETURNING *";
        params = [quantity, id];
      } else if (operation === "add") {
        query =
          "UPDATE products SET initial_quantity = initial_quantity + $1, updated_at = NOW() WHERE id = $2 RETURNING *";
        params = [quantity, id];
      } else if (operation === "subtract") {
        query =
          "UPDATE products SET initial_quantity = GREATEST(initial_quantity - $1, 0), updated_at = NOW() WHERE id = $2 RETURNING *";
        params = [quantity, id];
      } else {
        return res
          .status(400)
          .json({ error: "Invalid operation. Use set, add, or subtract." });
      }

      const result = await pool.query(query, params);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      res.json({
        message: "Stock updated successfully",
        product: result.rows[0],
      });
    } catch (error) {
      console.error("Update stock error:", error);
      res
        .status(500)
        .json({ error: "Failed to update stock", details: error.message });
    }
  }

  async search(req, res) {
    const {
      gender,
      category,
      brand,
      price_min,
      price_max,
      size,
      color,
      availability,
      page = 1,
      limit = 20,
    } = req.query;

    const offset = (page - 1) * limit;

    try {
      let query = `
        SELECT p.*, 
               g.name as gender_name,
               c.name as category_name,
               b.name as brand_name,
               s.name as size_name,
               co.name as color_name,
               pq.sold_quantity,
               pq.current_quantity
        FROM products p
        LEFT JOIN genders g ON p.gender_id = g.id
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN sizes s ON p.size_id = s.id
        LEFT JOIN colors co ON p.color_id = co.id
        LEFT JOIN product_quantities pq ON p.id = pq.id
        WHERE p.is_active = true
      `;

      const params = [];
      let paramIndex = 1;

      if (gender) {
        query += ` AND g.name ILIKE $${paramIndex}`;
        params.push(gender);
        paramIndex++;
      }

      if (category) {
        query += ` AND c.name ILIKE $${paramIndex}`;
        params.push(category);
        paramIndex++;
      }

      if (brand) {
        query += ` AND b.name ILIKE $${paramIndex}`;
        params.push(brand);
        paramIndex++;
      }

      if (price_min) {
        query += ` AND p.discounted_price >= $${paramIndex}`;
        params.push(parseFloat(price_min));
        paramIndex++;
      }

      if (price_max) {
        query += ` AND p.discounted_price <= $${paramIndex}`;
        params.push(parseFloat(price_max));
        paramIndex++;
      }

      if (size) {
        query += ` AND s.name ILIKE $${paramIndex}`;
        params.push(size);
        paramIndex++;
      }

      if (color) {
        query += ` AND co.name ILIKE $${paramIndex}`;
        params.push(color);
        paramIndex++;
      }

      if (availability === "in_stock") {
        query += ` AND pq.current_quantity > 0`;
      } else if (availability === "out_of_stock") {
        query += ` AND pq.current_quantity <= 0`;
      }

      query += ` ORDER BY p.created_at DESC LIMIT $${paramIndex} OFFSET $${
        paramIndex + 1
      }`;
      params.push(parseInt(limit), offset);

      const result = await pool.query(query, params);

      let countQuery = `
        SELECT COUNT(*) 
        FROM products p
        LEFT JOIN genders g ON p.gender_id = g.id
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN sizes s ON p.size_id = s.id
        LEFT JOIN colors co ON p.color_id = co.id
        LEFT JOIN product_quantities pq ON p.id = pq.id
        WHERE p.is_active = true
      `;

      const countParams = params.slice(0, -2);
      let countParamIndex = 1;

      if (gender) {
        countQuery += ` AND g.name ILIKE $${countParamIndex}`;
        countParamIndex++;
      }
      if (category) {
        countQuery += ` AND c.name ILIKE $${countParamIndex}`;
        countParamIndex++;
      }
      if (brand) {
        countQuery += ` AND b.name ILIKE $${countParamIndex}`;
        countParamIndex++;
      }
      if (price_min) {
        countQuery += ` AND p.discounted_price >= $${countParamIndex}`;
        countParamIndex++;
      }
      if (price_max) {
        countQuery += ` AND p.discounted_price <= $${countParamIndex}`;
        countParamIndex++;
      }
      if (size) {
        countQuery += ` AND s.name ILIKE $${countParamIndex}`;
        countParamIndex++;
      }
      if (color) {
        countQuery += ` AND co.name ILIKE $${countParamIndex}`;
        countParamIndex++;
      }
      if (availability === "in_stock") {
        countQuery += ` AND pq.current_quantity > 0`;
      } else if (availability === "out_of_stock") {
        countQuery += ` AND pq.current_quantity <= 0`;
      }

      const countResult = await pool.query(countQuery, countParams);
      const total = parseInt(countResult.rows[0].count);

      res.json({
        products: result.rows,
        filters: {
          gender,
          category,
          brand,
          price_min,
          price_max,
          size,
          color,
          availability,
        },
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      console.error("Search products error:", error);
      res
        .status(500)
        .json({ error: "Failed to search products", details: error.message });
    }
  }

  async getQuantity(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `SELECT * FROM product_quantities WHERE id = $1`,
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }

      const product = result.rows[0];

      res.json({
        product_id: parseInt(product.id),
        name: product.name,
        initial_quantity: parseInt(product.initial_quantity),
        sold_quantity: parseInt(product.sold_quantity),
        current_quantity: parseInt(product.current_quantity),
      });
    } catch (error) {
      console.error("Get quantity error:", error);
      res.status(500).json({
        error: "Failed to get product quantity",
        details: error.message,
      });
    }
  }
}

module.exports = new ProductController();
