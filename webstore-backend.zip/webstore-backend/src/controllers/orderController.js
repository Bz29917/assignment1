const { pool } = require("../config/database");

class OrderController {
  generateOrderNumber() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `ORD-${timestamp}-${random}`;
  }

  async getAll(req, res) {
    const { page = 1, limit = 20, status } = req.query;
    const offset = (page - 1) * limit;

    try {
      let query = `
        SELECT o.*, 
               c.first_name, c.last_name, c.email,
               COUNT(oi.id) as items_count
        FROM orders o
        LEFT JOIN clients c ON o.client_id = c.id
        LEFT JOIN order_items oi ON o.id = oi.order_id
      `;

      const params = [];
      if (status) {
        query += " WHERE o.status = $1";
        params.push(status);
      }

      query +=
        " GROUP BY o.id, c.id ORDER BY o.created_at DESC LIMIT $" +
        (params.length + 1) +
        " OFFSET $" +
        (params.length + 2);
      params.push(limit, offset);

      const result = await pool.query(query, params);

      let countQuery = "SELECT COUNT(*) FROM orders";
      const countParams = [];
      if (status) {
        countQuery += " WHERE status = $1";
        countParams.push(status);
      }

      const countResult = await pool.query(countQuery, countParams);
      const total = parseInt(countResult.rows[0].count);

      res.json({
        orders: result.rows,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      console.error("Get orders error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch orders", details: error.message });
    }
  }

  async getById(req, res) {
    const { id } = req.params;

    try {
      const orderResult = await pool.query(
        `SELECT o.*, 
                c.first_name, c.last_name, c.email, c.phone, c.address, c.city, c.country
         FROM orders o
         LEFT JOIN clients c ON o.client_id = c.id
         WHERE o.id = $1`,
        [id]
      );

      if (orderResult.rows.length === 0) {
        return res.status(404).json({ error: "Order not found" });
      }

      const order = orderResult.rows[0];

      const itemsResult = await pool.query(
        `SELECT oi.*, 
                p.name as current_product_name,
                p.description as product_description
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.order_id = $1`,
        [id]
      );

      order.items = itemsResult.rows;

      res.json({ order });
    } catch (error) {
      console.error("Get order error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch order", details: error.message });
    }
  }

  async create(req, res) {
    const { client_id, items, notes } = req.body;

    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      const clientCheck = await client.query(
        "SELECT * FROM clients WHERE id = $1",
        [client_id]
      );
      if (clientCheck.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ error: "Client not found" });
      }

      const order_number = this.generateOrderNumber();

      const orderResult = await client.query(
        `INSERT INTO orders (client_id, order_number, status, notes, total_amount)
         VALUES ($1, $2, 'pending', $3, 0) RETURNING *`,
        [client_id, order_number, notes]
      );

      const order = orderResult.rows[0];
      let totalAmount = 0;

      for (const item of items) {
        const { product_id, quantity } = item;

        const productResult = await client.query(
          "SELECT * FROM product_quantities WHERE id = $1",
          [product_id]
        );

        if (productResult.rows.length === 0) {
          await client.query("ROLLBACK");
          return res
            .status(404)
            .json({ error: `Product with ID ${product_id} not found` });
        }

        const product = productResult.rows[0];

        if (product.current_quantity < quantity) {
          await client.query("ROLLBACK");
          return res.status(400).json({
            error: `Insufficient stock for product "${product.name}". Available: ${product.current_quantity}, Requested: ${quantity}`,
          });
        }

        const priceResult = await client.query(
          "SELECT price, discounted_price FROM products WHERE id = $1",
          [product_id]
        );

        const unit_price = parseFloat(priceResult.rows[0].discounted_price);
        const total_price = unit_price * quantity;
        totalAmount += total_price;

        await client.query(
          `INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price, total_price)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            order.id,
            product_id,
            product.name,
            quantity,
            unit_price,
            total_price,
          ]
        );
      }

      await client.query("UPDATE orders SET total_amount = $1 WHERE id = $2", [
        totalAmount,
        order.id,
      ]);

      await client.query("COMMIT");

      const completeOrder = await this.getOrderWithItems(order.id);

      res.status(201).json({
        message: "Order created successfully",
        order: completeOrder,
      });
    } catch (error) {
      await client.query("ROLLBACK");
      console.error("Create order error:", error);
      res
        .status(500)
        .json({ error: "Failed to create order", details: error.message });
    } finally {
      client.release();
    }
  }

  async updateStatus(req, res) {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = [
      "pending",
      "confirmed",
      "processing",
      "shipped",
      "delivered",
      "cancelled",
    ];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: "Invalid status",
        validStatuses,
      });
    }

    try {
      let timestampField = "";

      switch (status) {
        case "confirmed":
          timestampField = ", confirmed_at = NOW()";
          break;
        case "shipped":
          timestampField = ", shipped_at = NOW()";
          break;
        case "delivered":
          timestampField = ", delivered_at = NOW()";
          break;
      }

      const result = await pool.query(
        `UPDATE orders SET status = $1, updated_at = NOW()${timestampField} WHERE id = $2 RETURNING *`,
        [status, id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Order not found" });
      }

      res.json({
        message: "Order status updated successfully",
        order: result.rows[0],
      });
    } catch (error) {
      console.error("Update order status error:", error);
      res.status(500).json({
        error: "Failed to update order status",
        details: error.message,
      });
    }
  }

  async cancel(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `UPDATE orders SET status = 'cancelled', updated_at = NOW() WHERE id = $1 RETURNING *`,
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Order not found" });
      }

      res.json({
        message: "Order cancelled successfully",
        order: result.rows[0],
      });
    } catch (error) {
      console.error("Cancel order error:", error);
      res
        .status(500)
        .json({ error: "Failed to cancel order", details: error.message });
    }
  }

  async getOrderWithItems(orderId) {
    const orderResult = await pool.query(
      `SELECT o.*, 
              c.first_name, c.last_name, c.email
       FROM orders o
       LEFT JOIN clients c ON o.client_id = c.id
       WHERE o.id = $1`,
      [orderId]
    );

    const order = orderResult.rows[0];

    const itemsResult = await pool.query(
      "SELECT * FROM order_items WHERE order_id = $1",
      [orderId]
    );

    order.items = itemsResult.rows;
    return order;
  }

  async getStatistics(req, res) {
    try {
      const stats = await pool.query(`
        SELECT 
          COUNT(*) as total_orders,
          COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
          COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_orders,
          COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing_orders,
          COUNT(CASE WHEN status = 'shipped' THEN 1 END) as shipped_orders,
          COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders,
          COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders,
          SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END) as total_revenue,
          AVG(CASE WHEN status != 'cancelled' THEN total_amount ELSE NULL END) as average_order_value
        FROM orders
      `);

      res.json({ statistics: stats.rows[0] });
    } catch (error) {
      console.error("Get order statistics error:", error);
      res.status(500).json({
        error: "Failed to get order statistics",
        details: error.message,
      });
    }
  }
}

const orderController = new OrderController();

module.exports = {
  getAll: orderController.getAll.bind(orderController),
  getById: orderController.getById.bind(orderController),
  create: orderController.create.bind(orderController),
  updateStatus: orderController.updateStatus.bind(orderController),
  cancel: orderController.cancel.bind(orderController),
  getStatistics: orderController.getStatistics.bind(orderController),
};
