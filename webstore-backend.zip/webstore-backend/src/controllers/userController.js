const bcrypt = require("bcrypt");
const { pool } = require("../config/database");

class UserController {
  async getAll(req, res) {
    try {
      const result = await pool.query(
        `SELECT id, username, email, role, first_name, last_name, is_active, created_at, last_login
         FROM users
         ORDER BY created_at DESC`
      );

      res.json({ users: result.rows });
    } catch (error) {
      console.error("Get users error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch users", details: error.message });
    }
  }

  async getById(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `SELECT id, username, email, role, first_name, last_name, is_active, created_at, last_login
         FROM users WHERE id = $1`,
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ user: result.rows[0] });
    } catch (error) {
      console.error("Get user error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch user", details: error.message });
    }
  }

  async update(req, res) {
    const { id } = req.params;
    const { username, email, role, first_name, last_name, is_active } =
      req.body;

    if (req.user.id !== parseInt(id) && req.user.role !== "admin") {
      return res
        .status(403)
        .json({ error: "You can only update your own account" });
    }

    try {
      let updateQuery;
      let params;

      if (req.user.role === "admin") {
        updateQuery = `
          UPDATE users 
          SET username = COALESCE($1, username),
              email = COALESCE($2, email),
              role = COALESCE($3, role),
              first_name = COALESCE($4, first_name),
              last_name = COALESCE($5, last_name),
              is_active = COALESCE($6, is_active),
              updated_at = NOW()
          WHERE id = $7
          RETURNING id, username, email, role, first_name, last_name, is_active, updated_at
        `;
        params = [username, email, role, first_name, last_name, is_active, id];
      } else {
        updateQuery = `
          UPDATE users 
          SET username = COALESCE($1, username),
              email = COALESCE($2, email),
              first_name = COALESCE($3, first_name),
              last_name = COALESCE($4, last_name),
              updated_at = NOW()
          WHERE id = $5
          RETURNING id, username, email, role, first_name, last_name, is_active, updated_at
        `;
        params = [username, email, first_name, last_name, id];
      }

      const result = await pool.query(updateQuery, params);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({
        message: "User updated successfully",
        user: result.rows[0],
      });
    } catch (error) {
      console.error("Update user error:", error);

      if (error.code === "23505") {
        return res
          .status(400)
          .json({ error: "Username or email already exists" });
      }

      res
        .status(500)
        .json({ error: "Failed to update user", details: error.message });
    }
  }

  async delete(req, res) {
    const { id } = req.params;

    if (req.user.id === parseInt(id)) {
      return res
        .status(400)
        .json({ error: "You cannot delete your own account" });
    }

    try {
      const result = await pool.query(
        "DELETE FROM users WHERE id = $1 RETURNING *",
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Delete user error:", error);
      res
        .status(500)
        .json({ error: "Failed to delete user", details: error.message });
    }
  }

  async deactivate(req, res) {
    const { id } = req.params;

    if (req.user.id === parseInt(id)) {
      return res
        .status(400)
        .json({ error: "You cannot deactivate your own account" });
    }

    try {
      const result = await pool.query(
        "UPDATE users SET is_active = false, updated_at = NOW() WHERE id = $1 RETURNING *",
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ message: "User deactivated successfully" });
    } catch (error) {
      console.error("Deactivate user error:", error);
      res
        .status(500)
        .json({ error: "Failed to deactivate user", details: error.message });
    }
  }

  async activate(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        "UPDATE users SET is_active = true, updated_at = NOW() WHERE id = $1 RETURNING *",
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ message: "User activated successfully" });
    } catch (error) {
      console.error("Activate user error:", error);
      res
        .status(500)
        .json({ error: "Failed to activate user", details: error.message });
    }
  }

  async updatePassword(req, res) {
    const { id } = req.params;
    const { newPassword } = req.body;

    if (req.user.id !== parseInt(id) && req.user.role !== "admin") {
      return res
        .status(403)
        .json({ error: "You can only update your own password" });
    }

    try {
      const saltRounds = 10;
      const password_hash = await bcrypt.hash(newPassword, saltRounds);

      const result = await pool.query(
        "UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2 RETURNING id",
        [password_hash, id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Update password error:", error);
      res
        .status(500)
        .json({ error: "Failed to update password", details: error.message });
    }
  }

  async getByRole(req, res) {
    const { role } = req.params;

    const validRoles = ["admin", "advanced_user", "simple_user"];

    if (!validRoles.includes(role)) {
      return res.status(400).json({
        error: "Invalid role",
        validRoles,
      });
    }

    try {
      const result = await pool.query(
        `SELECT id, username, email, role, first_name, last_name, is_active, created_at, last_login
         FROM users WHERE role = $1
         ORDER BY created_at DESC`,
        [role]
      );

      res.json({
        role,
        users: result.rows,
        count: result.rows.length,
      });
    } catch (error) {
      console.error("Get users by role error:", error);
      res.status(500).json({
        error: "Failed to fetch users by role",
        details: error.message,
      });
    }
  }
}

module.exports = new UserController();
