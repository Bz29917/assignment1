const { pool } = require("../config/database");

class ClientController {
  async getAll(req, res) {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    try {
      const result = await pool.query(
        "SELECT * FROM clients ORDER BY created_at DESC LIMIT $1 OFFSET $2",
        [limit, offset]
      );

      const countResult = await pool.query("SELECT COUNT(*) FROM clients");
      const total = parseInt(countResult.rows[0].count);

      res.json({
        clients: result.rows,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      console.error("Get clients error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch clients", details: error.message });
    }
  }

  async getById(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query("SELECT * FROM clients WHERE id = $1", [
        id,
      ]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Client not found" });
      }

      res.json({ client: result.rows[0] });
    } catch (error) {
      console.error("Get client error:", error);
      res
        .status(500)
        .json({ error: "Failed to fetch client", details: error.message });
    }
  }

  async create(req, res) {
    const {
      first_name,
      last_name,
      email,
      phone,
      address,
      city,
      country,
      postal_code,
    } = req.body;

    try {
      const emailCheck = await pool.query(
        "SELECT * FROM clients WHERE email = $1",
        [email]
      );

      if (emailCheck.rows.length > 0) {
        return res
          .status(400)
          .json({ error: "Client with this email already exists" });
      }

      const result = await pool.query(
        `INSERT INTO clients (first_name, last_name, email, phone, address, city, country, postal_code)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [
          first_name,
          last_name,
          email,
          phone,
          address,
          city,
          country,
          postal_code,
        ]
      );

      res.status(201).json({
        message: "Client created successfully",
        client: result.rows[0],
      });
    } catch (error) {
      console.error("Create client error:", error);
      res
        .status(500)
        .json({ error: "Failed to create client", details: error.message });
    }
  }

  async update(req, res) {
    const { id } = req.params;
    const {
      first_name,
      last_name,
      email,
      phone,
      address,
      city,
      country,
      postal_code,
    } = req.body;

    try {
      const result = await pool.query(
        `UPDATE clients 
         SET first_name = COALESCE($1, first_name),
             last_name = COALESCE($2, last_name),
             email = COALESCE($3, email),
             phone = COALESCE($4, phone),
             address = COALESCE($5, address),
             city = COALESCE($6, city),
             country = COALESCE($7, country),
             postal_code = COALESCE($8, postal_code),
             updated_at = NOW()
         WHERE id = $9 RETURNING *`,
        [
          first_name,
          last_name,
          email,
          phone,
          address,
          city,
          country,
          postal_code,
          id,
        ]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Client not found" });
      }

      res.json({
        message: "Client updated successfully",
        client: result.rows[0],
      });
    } catch (error) {
      console.error("Update client error:", error);
      res
        .status(500)
        .json({ error: "Failed to update client", details: error.message });
    }
  }

  async delete(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        "DELETE FROM clients WHERE id = $1 RETURNING *",
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Client not found" });
      }

      res.json({ message: "Client deleted successfully" });
    } catch (error) {
      console.error("Delete client error:", error);

      if (error.code === "23503") {
        return res.status(400).json({
          error: "Cannot delete client because they have associated orders",
        });
      }

      res
        .status(500)
        .json({ error: "Failed to delete client", details: error.message });
    }
  }

  async getOrders(req, res) {
    const { id } = req.params;

    try {
      const result = await pool.query(
        `SELECT o.*, 
                COUNT(oi.id) as items_count
         FROM orders o
         LEFT JOIN order_items oi ON o.id = oi.order_id
         WHERE o.client_id = $1
         GROUP BY o.id
         ORDER BY o.created_at DESC`,
        [id]
      );

      res.json({
        client_id: id,
        orders: result.rows,
        count: result.rows.length,
      });
    } catch (error) {
      console.error("Get client orders error:", error);
      res.status(500).json({
        error: "Failed to fetch client orders",
        details: error.message,
      });
    }
  }
}

module.exports = new ClientController();
